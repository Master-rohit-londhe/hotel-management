﻿Imports CrystalDecisions.CrystalReports.Engine

Public Class billreceipt

    Private Sub billreceipt_Load(sender As Object, e As EventArgs) Handles Me.Load
        cn.Open()
        strsql = "select * from tb_salebill_master where InvoiceId=" & Val(frm_bill.txtno.Text) & " "
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_salebill_master")
        oadp.Fill(otable)
        CrystalReportViewer1.RefreshReport()
        CrystalReportViewer1.Refresh()
        rptbill1.PrintToPrinter(1, False, 0, 0)
        cn.Close()
    End Sub

    Private Sub rptbill1_InitReport(sender As Object, e As EventArgs) Handles rptbill1.InitReport
        Dim s As String
        s = "{tb_salebill_master.Customer}='" & frm_bill.cmbcust.Text & "'"
        s = "{tb_salebill_master.InvoiceId}=" & frm_bill.txtno.Text & ""

        CrystalReportViewer1.SelectionFormula = s
    End Sub
End Class