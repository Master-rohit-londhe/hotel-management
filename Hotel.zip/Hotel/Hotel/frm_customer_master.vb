﻿Imports System.Data.OleDb

Public Class frm_customer_master

    Private Sub frm_customer_master_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        clear()
    End Sub
    Private Sub txtdetails_LostFocus(sender As Object, e As EventArgs) Handles txtdetails.LostFocus
        btnsave.Focus()
    End Sub
    Sub clear()
        On Error Resume Next
        btnsave.Enabled = True
        btnmodify.Enabled = False
        dtp.Text = ""
        txtname.Text = ""
        txtaddr.Text = ""
        txtmob.Text = ""
        txtgstno.Text = ""
        cmbtype.Text = ""
        txtdetails.Text = ""
        dtp.Focus()
        cn.Open()
        cmd = New OleDb.OleDbCommand("select * from tb_customer_info", cn)
        Dim reader As OleDbDataReader = cmd.ExecuteReader
        If (reader.Read = True) Then
            strsql = "select max(CustId)from tb_customer_info"
            cmd = New OleDb.OleDbCommand(strsql, cn)
            oadp = New OleDb.OleDbDataAdapter(cmd)
            otable = New DataTable("tb_customer_info")
            oadp.Fill(otable)
            row = otable.Rows(0)
            txtcustomerid.Text = row.Item(0) + 1
        ElseIf (reader.Read = False) Then
            txtcustomerid.Text = "1"
        End If
        cn.Close()
    End Sub
    Sub generateID()
        cn.Open()
        cmd = New OleDb.OleDbCommand("select * from tb_customer_info", cn)
        Dim reader As OleDbDataReader = cmd.ExecuteReader
        If (reader.Read = True) Then
            strsql = "select max(CustId)from tb_customer_info"
            cmd = New OleDb.OleDbCommand(strsql, cn)
            oadp = New OleDb.OleDbDataAdapter(cmd)
            otable = New DataTable("tb_customer_info")
            oadp.Fill(otable)
            row = otable.Rows(0)
            txtcustomerid.Text = row.Item(0) + 1
        ElseIf (reader.Read = False) Then
            txtcustomerid.Text = "1"
        End If
        cn.Close()
    End Sub
    Sub clearfields()
        txtcustomerid.Text = ""
        dtp.Text = ""
        txtname.Text = ""
        txtaddr.Text = ""
        txtmob.Text = ""
        txtgstno.Text = ""
        cmbtype.Text = ""
        txtdetails.Text = ""
    End Sub
    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        On Error Resume Next
        cn.Open()
        If txtname.Text = "" Then
            MsgBox("Please enter name", MsgBoxStyle.OkOnly, "Error")
            txtname.Focus()
        Else
            strsql = "SELECT * FROM tb_customer_info WHERE CustName ='" & txtname.Text & "'"
            cmd = New OleDbCommand(strsql, cn)
            Dim dr As OleDbDataReader
            dr = cmd.ExecuteReader()
            If Not dr.HasRows Then
                strsql = "insert into tb_customer_info values(" & Val(txtcustomerid.Text) & ",CDate('" & dtp.Text & "'),'" & txtname.Text & "','" & txtaddr.Text & "'," & Val(txtmob.Text) & ",'" & txtgstno.Text & "','" & cmbtype.Text & "','" & txtdetails.Text & "')"
                cmd = New OleDb.OleDbCommand(strsql, cn)
                cmd.ExecuteNonQuery()
                MsgBox("Record is Saved")
                clear()
            Else
                MsgBox("This name already exist...Use another name")
                txtname.Focus()
            End If
        End If
        cn.Close()
        generateID()


    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        clear()
    End Sub

    Private Sub btnview_Click(sender As Object, e As EventArgs) Handles btnview.Click
        frm_customer_view.show()
    End Sub

    Private Sub btnmodify_Click(sender As Object, e As EventArgs) Handles btnmodify.Click
        On Error Resume Next
        cn.Open()
        strsql = "update [tb_customer_info] set [Dated]=CDate('" & dtp.Text & "'),[CustName]='" & txtname.Text & "',[Address]='" & txtaddr.Text & "',[MobNo]=" & Val(txtmob.Text) & ",[GSTNo]='" & txtgstno.Text & "',[Type]='" & cmbtype.Text & "',[Details]='" & txtdetails.Text & "' where [CustId]=" & Val(txtcustomerid.Text) & "  "
        cmd = New OleDb.OleDbCommand(strsql, cn)
        cmd.ExecuteNonQuery()
        MsgBox("Record is Updated")
        cn.Close()
        clear()
    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        On Error Resume Next
        If (MsgBox("Are You Sure", MsgBoxStyle.YesNoCancel, "Hotel") = DialogResult.Yes) Then
            cn.Open()
            strsql = "delete from tb_customer_info where CustId=" & Val(txtcustomerid.Text) & ""
            cmd = New OleDb.OleDbCommand(strsql, cn)
            cmd.ExecuteNonQuery()
            MsgBox("Record is Deleted")
            cn.Close()
            clear()
        End If
    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
    End Sub
    Private Sub txtname_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtname.LostFocus
        If IsNumeric(txtname.Text) = True Then
            MsgBox("Enter Character Only")
            txtname.Clear()
            txtname.Focus()
        End If

    End Sub

    Private Sub txtmob_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtmob.LostFocus
        If IsNumeric(txtmob.Text) = False Then
            MsgBox("Enter Number Only")
            txtmob.Clear()
            txtmob.Focus()
        End If
    End Sub

    Private Sub btnnew_Click(sender As Object, e As EventArgs) Handles btnnew.Click
        clear()
    End Sub
End Class