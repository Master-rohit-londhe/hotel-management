﻿Imports System.Data.OleDb

Public Class frm_rawmaterial_view
    Dim cmd, cmd1 As OleDb.OleDbCommand
    Dim strsql As String

    Private Sub frm_rawmaterial_view_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then
            btnok.PerformClick()
        End If
    End Sub
    Private Sub frm_rawmaterial_view_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        On Error Resume Next
        Me.Show()

        cn.Open()
        Dim strsql As String
        strsql = " select * from tb_RawMaterial_info order by Item_Id asc"
        Dim cmd As OleDbCommand = New OleDbCommand(strsql, cn)
        Dim oadp As OleDbDataAdapter = New OleDb.OleDbDataAdapter(cmd)
        Dim otable As DataTable = New DataTable("tb_RawMaterial_info")
        oadp.Fill(otable)
        DataGridViewraw.DataSource = otable
        cn.Close()
        DataGridViewraw.Rows(0).Cells(0).Selected = True
        DataGridViewraw.Select()
    End Sub
    Private Sub btnok_Click(sender As Object, e As EventArgs) Handles btnok.Click
        ' RawMaterial.TextBoxrawid.ReadOnly = True
        Dim i As Integer
        Try
            i = DataGridViewraw.CurrentRow.Index
            frm_rawmaterial.TextBoxrawid.Text = DataGridViewraw.Item(0, i).Value
            frm_rawmaterial.TextBoxrawitemname.Text = DataGridViewraw.Item(1, i).Value
            frm_rawmaterial.TextBoxrawsupp.Text = DataGridViewraw.Item(2, i).Value
            frm_rawmaterial.TextBoxrawcost.Text = DataGridViewraw.Item(3, i).Value
            frm_rawmaterial.TextBoxrawcompnm.Text = DataGridViewraw.Item(4, i).Value
            frm_rawmaterial.DateTimePickerraw.Text = DataGridViewraw.Item(5, i).Value
        Catch ex As Exception

        End Try
        frm_rawmaterial.Show()
        frm_rawmaterial.btnupdate.Enabled = True
        Me.Close()
    End Sub

    Private Sub btnbyid_Click(sender As Object, e As EventArgs) Handles btnbyid.Click
        On Error Resume Next
        Dim id As Double
        cn.Open()
        id = InputBox("Enter Material Id", "Hotel")
        ''Search From billing Table
        strsql = "select * from tb_RawMaterial_info where Item_Id=" & id
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_RawMaterial_info")
        oadp.Fill(otable)
        DataGridViewraw.DataSource = otable
        If otable.Rows.Count = 0 Then
            MsgBox("This Material Id Does Not Exist", MsgBoxStyle.DefaultButton1, "Hotel")
        Else
            row = otable.Rows(0)

        End If
        cn.Close()
    End Sub

    Private Sub btnbynm_Click(sender As Object, e As EventArgs) Handles btnbynm.Click
        On Error Resume Next
        Dim name As String
        cn.Open()
        name = InputBox("Enter Material Name", "Hotel")
        ''Search From billing Table
        strsql = "select * from tb_RawMaterial_info where Item_Name like '%" & name & "%'"
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_RawMaterial_info")
        oadp.Fill(otable)
        DataGridViewraw.DataSource = otable
        If otable.Rows.Count = 0 Then
            MsgBox("This Material Name Does Not Exist", MsgBoxStyle.DefaultButton1, "Hotel")
        Else
            row = otable.Rows(0)

        End If
        cn.Close()
    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
    End Sub

    Private Sub btnshowall_Click(sender As Object, e As EventArgs) Handles btnshowall.Click
        On Error Resume Next
        cn.Open()
        Dim strsql As String
        strsql = " select * from tb_RawMaterial_info"
        Dim cmd As OleDbCommand = New OleDbCommand(strsql, cn)
        Dim oadp As OleDbDataAdapter = New OleDb.OleDbDataAdapter(cmd)
        Dim otable As DataTable = New DataTable("tb_billing_info")
        oadp.Fill(otable)
        DataGridViewraw.DataSource = otable
        cn.Close()
    End Sub
End Class