﻿Imports System.Data.OleDb

Public Class frm_material_view
    Sub ChangeLang()
        Dim strikethrough_style As New DataGridViewCellStyle

        strikethrough_style.Font = New Font("Shivaji01", 11, FontStyle.Regular)
        'strikethrough_style.BackColor = Color.Red

        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim i As Integer
            For i = 0 To DataGridView1.Columns.Count - 1
                row.Cells(4).Style = strikethrough_style
            Next
        Next
    End Sub
    Private Sub frm_material_view_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then
            btnok.PerformClick()
        End If
    End Sub

    Private Sub frm_material_view_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadData()
    End Sub
    Sub loadData()
        On Error Resume Next
        cn.Open()
        Dim strsql As String
        strsql = " select * from tb_material_info order by MatId asc"
        Dim cmd As OleDbCommand = New OleDbCommand(strsql, cn)
        Dim oadp As OleDbDataAdapter = New OleDb.OleDbDataAdapter(cmd)
        Dim otable As DataTable = New DataTable("tb_material_info")
        oadp.Fill(otable)
        DataGridView1.DataSource = otable
        cn.Close()
        DataGridView1.Rows(0).Cells(0).Selected = True
        DataGridView1.Select()
        ChangeLang()
    End Sub
    Private Sub DataGridView1_CellPainting(sender As Object, e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        If e.ColumnIndex = -1 AndAlso e.RowIndex > -1 AndAlso e.RowIndex < DataGridView1.Rows.Count - 1 Then
            Dim indexString As String = (e.RowIndex + 1).ToString
            Dim sz As SizeF = e.Graphics.MeasureString(indexString, DataGridView1.Font)
            Dim pt As New PointF(e.CellBounds.Width - sz.Width, e.CellBounds.Y + (e.CellBounds.Height / 2 - sz.Height / 2))
            e.Paint(e.ClipBounds, DataGridViewPaintParts.All)
            e.Graphics.DrawString(indexString, DataGridView1.Font, Brushes.Black, pt)
            e.Handled = True
        End If
    End Sub

    Private Sub btnid_Click(sender As Object, e As EventArgs) Handles btnid.Click
        On Error Resume Next
        Dim id As Double
        cn.Open()
        id = InputBox("Enter Material Id.", "Hotel")
        strsql = " select * from tb_material_info where MatId=" & id
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_material_info")
        oadp.Fill(otable)
        DataGridView1.DataSource = otable
        If otable.Rows.Count = 0 Then
            MsgBox("This Id. Does Not Exist", MsgBoxStyle.DefaultButton1, "Hotel")
        Else
            row = otable.Rows(0)
        End If
        cn.Close()
        ChangeLang()
    End Sub

    Private Sub btnname_Click(sender As Object, e As EventArgs) Handles btnname.Click
        On Error Resume Next
        Dim nm As String
        cn.Open()
        nm = InputBox("Enter Material Name", "Hotel")
        strsql = " select * from tb_material_info  where MaterialName like '%" & nm & "%'"
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_customer_info")
        oadp.Fill(otable)
        DataGridView1.DataSource = otable
        If otable.Rows.Count = 0 Then
            MsgBox("This Material Name Does Not Exist", MsgBoxStyle.DefaultButton1, "Hotel")
        Else
            row = otable.Rows(0)
        End If
        cn.Close()
        ChangeLang()
    End Sub

    Private Sub btntype_Click(sender As Object, e As EventArgs) Handles btntype.Click
        On Error Resume Next
        Dim type As String
        cn.Open()
        type = InputBox("Enter Material Type", "Hotel")
        strsql = " select * from tb_material_info  where Type like '%" & type & "%'"
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_material_info")
        oadp.Fill(otable)
        DataGridView1.DataSource = otable
        If otable.Rows.Count = 0 Then
            MsgBox("This Material Type Does Not Exist", MsgBoxStyle.DefaultButton1, "Hotel")
        Else
            row = otable.Rows(0)
        End If
        cn.Close()
        ChangeLang()
    End Sub

    Private Sub btnshowall_Click(sender As Object, e As EventArgs) Handles btnshowall.Click
        loadData()
    End Sub

    Private Sub btnok_Click(sender As Object, e As EventArgs) Handles btnok.Click
        frm_material.clearfields()
        Dim i As Integer
        Try
            i = DataGridView1.CurrentRow.Index
            frm_material.txtid.Text = DataGridView1.Item(0, i).Value
            frm_material.dtp.Text = DataGridView1.Item(1, i).Value
            frm_material.cmbtype.Text = DataGridView1.Item(2, i).Value
            frm_material.txtname.Text = DataGridView1.Item(3, i).Value
            frm_material.txtmatnm1.Text = DataGridView1.Item(4, i).Value
            frm_material.cmbcat.Text = DataGridView1.Item(5, i).Value
            frm_material.txtprice.Text = DataGridView1.Item(6, i).Value
            frm_material.txtqty.Text = DataGridView1.Item(7, i).Value
            frm_material.cmbunit.Text = DataGridView1.Item(8, i).Value
            frm_material.txttotamt.Text = DataGridView1.Item(9, i).Value
        Catch ex As Exception

        End Try
        frm_material.Show()
        frm_material.btnmodify.Enabled = True
        frm_material.btnsave.Enabled = False
        frm_material.btndelete.Enabled = True
        Me.Close()
    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
    End Sub
End Class