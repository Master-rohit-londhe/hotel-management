﻿Imports System.Data.OleDb

Public Class frm_bill_view

    Private Sub frm_bill_view_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then
            btnok.PerformClick()
        End If
    End Sub

    Private Sub frm_bill_view_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadData()
    End Sub
    Sub LoadData()
        On Error Resume Next
        cn.Open()
        Dim strsql As String
        strsql = " select * from tb_salebill_master order by InvoiceId asc"
        Dim cmd As OleDbCommand = New OleDbCommand(strsql, cn)
        Dim oadp As OleDbDataAdapter = New OleDb.OleDbDataAdapter(cmd)
        Dim otable As DataTable = New DataTable("tb_salebill_master")
        oadp.Fill(otable)
        DataGridView1.DataSource = otable
        cn.Close()
        DataGridView1.Rows(0).Cells(0).Selected = True
        DataGridView1.Select()
    End Sub
    Private Sub DataGridView1_CellPainting(sender As Object, e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        If e.ColumnIndex = -1 AndAlso e.RowIndex > -1 AndAlso e.RowIndex < DataGridView1.Rows.Count - 1 Then
            Dim indexString As String = (e.RowIndex + 1).ToString
            Dim sz As SizeF = e.Graphics.MeasureString(indexString, DataGridView1.Font)
            Dim pt As New PointF(e.CellBounds.Width - sz.Width, e.CellBounds.Y + (e.CellBounds.Height / 2 - sz.Height / 2))
            e.Paint(e.ClipBounds, DataGridViewPaintParts.All)
            e.Graphics.DrawString(indexString, DataGridView1.Font, Brushes.Black, pt)
            e.Handled = True
        End If
    End Sub

    Private Sub btnid_Click(sender As Object, e As EventArgs) Handles btnid.Click
        On Error Resume Next
        Dim id As Double
        cn.Open()
        id = InputBox("Enter Invoice No.", "Hotel")
        ''Search From billing Table
        strsql = " select * from tb_salebill_master where InvoiceId=" & id
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_salebill_master")
        oadp.Fill(otable)
        DataGridView1.DataSource = otable
        If otable.Rows.Count = 0 Then
            MsgBox("This Invoice No. Does Not Exist", MsgBoxStyle.Information, "Hotel")
        Else
            row = otable.Rows(0)

        End If
        cn.Close()
    End Sub

    Private Sub btncust_Click(sender As Object, e As EventArgs) Handles btncust.Click
        On Error Resume Next
        Dim nm As String
        cn.Open()
        nm = InputBox("Enter Customer Name", "Hotel")
        ''Search From billing Table
        strsql = " select * from tb_salebill_master  where Customer like '%" & nm & "%'"
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_salebill_master")
        oadp.Fill(otable)
        DataGridView1.DataSource = otable
        If otable.Rows.Count = 0 Then
            MsgBox("This Customer Name Does Not Exist", MsgBoxStyle.Information, "Hotel")
        Else
            row = otable.Rows(0)

        End If
        cn.Close()
    End Sub

    Private Sub btndt_Click(sender As Object, e As EventArgs) Handles btndt.Click
        On Error Resume Next
        Dim dt As String
        cn.Open()
        dt = InputBox("Enter Date", "Hotel")
        ''Search From billing Table
        strsql = " select * from tb_salebill_master  where Dated like '%" & dt & "%'"
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_salebill_master")
        oadp.Fill(otable)
        DataGridView1.DataSource = otable
        If otable.Rows.Count = 0 Then
            MsgBox("This Date Does Not Exist", MsgBoxStyle.Information, "Hotel")
        Else
            row = otable.Rows(0)

        End If
        cn.Close()
    End Sub

    Private Sub btnshowall_Click(sender As Object, e As EventArgs) Handles btnshowall.Click
        LoadData()
    End Sub

    Private Sub btnok_Click(sender As Object, e As EventArgs) Handles btnok.Click
        frm_bill.clear()
        frm_bill.Show()
        frm_bill.btnmodify.Enabled = True
        frm_bill.btndelete.Enabled = True
        frm_bill.btnsave.Enabled = False
        frm_bill.LinkLabel1.Visible = False
        '  frm_salebill.LinkLabel2.Visible = True
        Dim i As Integer
        Try
            i = DataGridView1.CurrentRow.Index
            frm_bill.txtno.Text = DataGridView1.Item(0, i).Value
            frm_bill.cmbcust.Text = DataGridView1.Item(1, i).Value
            frm_bill.dtp.Text = DataGridView1.Item(2, i).Value
            frm_bill.cmbpaymode.Text = DataGridView1.Item(3, i).Value
            frm_bill.txtsubtotamt.Text = DataGridView1.Item(4, i).Value
            frm_bill.txtadv.Text = DataGridView1.Item(5, i).Value
            frm_bill.txtdisc.Text = DataGridView1.Item(6, i).Value
            frm_bill.txtbillamt.Text = DataGridView1.Item(7, i).Value
            frm_bill.txttotqty.Text = DataGridView1.Item(8, i).Value
            frm_bill.txtnetamt.Text = DataGridView1.Item(9, i).Value
        Catch ex As Exception
        End Try



        ' Search From Detail Table
        frm_bill.DataGridView1.Rows.Clear()
        strsql = "select * from tb_salebill_detail where InvoiceId=" & Val(frm_bill.txtno.Text) & " order by MatId asc"
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_salebill_detail")
        oadp.Fill(otable)
        If otable.Rows.Count = 0 Then
            MsgBox("This Details Does Not Exist", MsgBoxStyle.Information, "Hotel")
        Else
            i = 0
            While i < otable.Rows.Count
                row = otable.Rows(i)
                Dim s() As String = {row.Item(1), row.Item(2), row.Item(3), row.Item(4), row.Item(5), row.Item(6), row.Item(7), row.Item(8)}
                frm_bill.DataGridView1.Rows.Add(s)
                i = i + 1
            End While
        End If
        cn.Close()
        frm_bill.caltotalqty()
        frm_bill.caltotalamt()
        Me.Close()
    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
    End Sub
End Class