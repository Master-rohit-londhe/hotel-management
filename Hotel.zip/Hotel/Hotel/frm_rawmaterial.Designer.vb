﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_rawmaterial
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnupdate = New System.Windows.Forms.Button()
        Me.btndelete = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBoxrawid = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Buttonshow = New System.Windows.Forms.Button()
        Me.Buttoncancel = New System.Windows.Forms.Button()
        Me.Buttonsave = New System.Windows.Forms.Button()
        Me.DateTimePickerraw = New System.Windows.Forms.DateTimePicker()
        Me.TextBoxrawcompnm = New System.Windows.Forms.TextBox()
        Me.TextBoxrawcost = New System.Windows.Forms.TextBox()
        Me.TextBoxrawsupp = New System.Windows.Forms.TextBox()
        Me.TextBoxrawitemname = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(214, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(143, 27)
        Me.Label1.TabIndex = 54
        Me.Label1.Text = "Raw Material"
        '
        'btnupdate
        '
        Me.btnupdate.BackColor = System.Drawing.Color.LightBlue
        Me.btnupdate.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnupdate.Font = New System.Drawing.Font("Times New Roman", 11.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnupdate.Location = New System.Drawing.Point(180, 244)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(75, 27)
        Me.btnupdate.TabIndex = 9
        Me.btnupdate.Text = "&Update"
        Me.btnupdate.UseVisualStyleBackColor = False
        '
        'btndelete
        '
        Me.btndelete.BackColor = System.Drawing.Color.LightBlue
        Me.btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btndelete.Font = New System.Drawing.Font("Times New Roman", 11.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndelete.Location = New System.Drawing.Point(261, 244)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(75, 27)
        Me.btndelete.TabIndex = 10
        Me.btndelete.Text = "&Delete"
        Me.btndelete.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.LightBlue
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Times New Roman", 11.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(18, 244)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 27)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "&New"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'TextBoxrawid
        '
        Me.TextBoxrawid.Enabled = False
        Me.TextBoxrawid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxrawid.Location = New System.Drawing.Point(241, 19)
        Me.TextBoxrawid.Name = "TextBoxrawid"
        Me.TextBoxrawid.ReadOnly = True
        Me.TextBoxrawid.Size = New System.Drawing.Size(130, 22)
        Me.TextBoxrawid.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(110, 18)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 19)
        Me.Label7.TabIndex = 30
        Me.Label7.Text = "Item Id :"
        '
        'Buttonshow
        '
        Me.Buttonshow.BackColor = System.Drawing.Color.LightBlue
        Me.Buttonshow.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Buttonshow.Font = New System.Drawing.Font("Times New Roman", 11.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonshow.Location = New System.Drawing.Point(342, 244)
        Me.Buttonshow.Name = "Buttonshow"
        Me.Buttonshow.Size = New System.Drawing.Size(120, 27)
        Me.Buttonshow.TabIndex = 11
        Me.Buttonshow.Text = "Show Re&port"
        Me.Buttonshow.UseVisualStyleBackColor = False
        '
        'Buttoncancel
        '
        Me.Buttoncancel.BackColor = System.Drawing.Color.LightBlue
        Me.Buttoncancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Buttoncancel.Font = New System.Drawing.Font("Times New Roman", 11.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttoncancel.Location = New System.Drawing.Point(468, 244)
        Me.Buttoncancel.Name = "Buttoncancel"
        Me.Buttoncancel.Size = New System.Drawing.Size(75, 27)
        Me.Buttoncancel.TabIndex = 12
        Me.Buttoncancel.Text = "&Cancel"
        Me.Buttoncancel.UseVisualStyleBackColor = False
        '
        'Buttonsave
        '
        Me.Buttonsave.BackColor = System.Drawing.Color.LightBlue
        Me.Buttonsave.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Buttonsave.Font = New System.Drawing.Font("Times New Roman", 11.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonsave.Location = New System.Drawing.Point(99, 244)
        Me.Buttonsave.Name = "Buttonsave"
        Me.Buttonsave.Size = New System.Drawing.Size(75, 27)
        Me.Buttonsave.TabIndex = 8
        Me.Buttonsave.Text = "&Save"
        Me.Buttonsave.UseVisualStyleBackColor = False
        '
        'DateTimePickerraw
        '
        Me.DateTimePickerraw.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePickerraw.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateTimePickerraw.Location = New System.Drawing.Point(241, 189)
        Me.DateTimePickerraw.Name = "DateTimePickerraw"
        Me.DateTimePickerraw.Size = New System.Drawing.Size(200, 22)
        Me.DateTimePickerraw.TabIndex = 6
        '
        'TextBoxrawcompnm
        '
        Me.TextBoxrawcompnm.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxrawcompnm.Location = New System.Drawing.Point(241, 155)
        Me.TextBoxrawcompnm.Name = "TextBoxrawcompnm"
        Me.TextBoxrawcompnm.Size = New System.Drawing.Size(200, 22)
        Me.TextBoxrawcompnm.TabIndex = 5
        '
        'TextBoxrawcost
        '
        Me.TextBoxrawcost.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxrawcost.Location = New System.Drawing.Point(241, 121)
        Me.TextBoxrawcost.Name = "TextBoxrawcost"
        Me.TextBoxrawcost.Size = New System.Drawing.Size(200, 22)
        Me.TextBoxrawcost.TabIndex = 4
        '
        'TextBoxrawsupp
        '
        Me.TextBoxrawsupp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxrawsupp.Location = New System.Drawing.Point(241, 87)
        Me.TextBoxrawsupp.Name = "TextBoxrawsupp"
        Me.TextBoxrawsupp.Size = New System.Drawing.Size(200, 22)
        Me.TextBoxrawsupp.TabIndex = 3
        '
        'TextBoxrawitemname
        '
        Me.TextBoxrawitemname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxrawitemname.Location = New System.Drawing.Point(241, 53)
        Me.TextBoxrawitemname.Name = "TextBoxrawitemname"
        Me.TextBoxrawitemname.Size = New System.Drawing.Size(200, 22)
        Me.TextBoxrawitemname.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(110, 188)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 19)
        Me.Label6.TabIndex = 21
        Me.Label6.Text = "Date :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(110, 154)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(116, 19)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "Company Name :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(110, 120)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 19)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Cost :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(110, 86)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(107, 19)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Supplier Name :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(110, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 19)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Item Name :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.SystemColors.Info
        Me.Label15.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.MediumBlue
        Me.Label15.Location = New System.Drawing.Point(470, 5)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(106, 14)
        Me.Label15.TabIndex = 56
        Me.Label15.Text = "Alt+P - Show Report"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnupdate)
        Me.GroupBox2.Controls.Add(Me.btndelete)
        Me.GroupBox2.Controls.Add(Me.Button1)
        Me.GroupBox2.Controls.Add(Me.TextBoxrawid)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Buttonshow)
        Me.GroupBox2.Controls.Add(Me.Buttoncancel)
        Me.GroupBox2.Controls.Add(Me.Buttonsave)
        Me.GroupBox2.Controls.Add(Me.DateTimePickerraw)
        Me.GroupBox2.Controls.Add(Me.TextBoxrawcompnm)
        Me.GroupBox2.Controls.Add(Me.TextBoxrawcost)
        Me.GroupBox2.Controls.Add(Me.TextBoxrawsupp)
        Me.GroupBox2.Controls.Add(Me.TextBoxrawitemname)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(5, 45)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(565, 299)
        Me.GroupBox2.TabIndex = 55
        Me.GroupBox2.TabStop = False
        '
        'frm_rawmaterial
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(580, 349)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.GroupBox2)
        Me.Name = "frm_rawmaterial"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Raw Material"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnupdate As System.Windows.Forms.Button
    Friend WithEvents btndelete As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TextBoxrawid As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Buttonshow As System.Windows.Forms.Button
    Friend WithEvents Buttoncancel As System.Windows.Forms.Button
    Friend WithEvents Buttonsave As System.Windows.Forms.Button
    Friend WithEvents DateTimePickerraw As System.Windows.Forms.DateTimePicker
    Friend WithEvents TextBoxrawcompnm As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxrawcost As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxrawsupp As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxrawitemname As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
End Class
