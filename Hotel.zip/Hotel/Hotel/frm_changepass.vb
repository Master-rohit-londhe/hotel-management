﻿Imports System.Data.OleDb

Public Class frm_changepass

    Private Sub frm_changepass_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        clear()
    End Sub
    Sub clear()
        cmbdesignation.SelectedIndex = 1
        cmbdesignation.Focus()
        txtusername.Text = ""
        txtoldpassword.Text = ""
        txtnewpassword.Text = ""
        txtconfirmpassword.Text = ""
    End Sub
    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        cn.Open()
        If cmbdesignation.Text = "" Then
            MsgBox("Please enter designation", MsgBoxStyle.OkOnly, "Error")
            cmbdesignation.Focus()
        ElseIf txtusername.Text = "" Then
            MsgBox("Please enter username", MsgBoxStyle.OkOnly, "Error")
            txtusername.Focus()
        ElseIf (Me.txtnewpassword.Text <> Me.txtconfirmpassword.Text) Then
            MsgBox("New Password and Confirn Password are not same", MsgBoxStyle.OkOnly, "Error")
            txtconfirmpassword.Focus()
        Else
            strsql = "SELECT username FROM tb_login WHERE username ='" & txtusername.Text & "'  "
            cmd = New OleDbCommand(strsql, cn)
            Dim dr As OleDbDataReader
            dr = cmd.ExecuteReader()

            strsql1 = "SELECT password FROM tb_login WHERE username ='" & txtusername.Text & "' and password='" & txtoldpassword.Text & "'  "
            cmd1 = New OleDbCommand(strsql1, cn)
            Dim dr1 As OleDbDataReader
            dr1 = cmd1.ExecuteReader()

            If Not dr.HasRows Then
                MsgBox("Username does not exist", MsgBoxStyle.OkOnly, "Error")
            ElseIf Not dr1.HasRows Then
                MsgBox("Old Password does not match", MsgBoxStyle.OkOnly, "Error")
            Else
                strsql = "update [tb_login] set [password]='" & txtnewpassword.Text & "' where [designation]='" & cmbdesignation.Text & "' And [username]='" & txtusername.Text & "'  "
                cmd = New OleDb.OleDbCommand(strsql, cn)
                cmd.ExecuteNonQuery()
                MsgBox("Password Changed Successfully", MsgBoxStyle.DefaultButton1, "Hotel")
            End If
        End If
        cn.Close()
    End Sub

    Private Sub btnnew_Click(sender As Object, e As EventArgs) Handles btnnew.Click
        clear()
    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
    End Sub
End Class