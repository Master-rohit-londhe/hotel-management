﻿Imports System.Data.OleDb

Public Class MaterialReport

    Private Sub MaterialReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadData()
    End Sub
    Sub loadData()
        On Error Resume Next
        cn.Open()
        Dim strsql As String
        strsql = " select * from tb_material_info order by MatId asc"
        Dim cmd As OleDbCommand = New OleDbCommand(strsql, cn)
        Dim oadp As OleDbDataAdapter = New OleDb.OleDbDataAdapter(cmd)
        Dim otable As DataTable = New DataTable("tb_material_info")
        oadp.Fill(otable)
        DataGridView1.DataSource = otable
        cn.Close()
        DataGridView1.Rows(0).Cells(0).Selected = True
        DataGridView1.Select()
    End Sub
    Private Sub DataGridView1_CellPainting(sender As Object, e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        If e.ColumnIndex = -1 AndAlso e.RowIndex > -1 AndAlso e.RowIndex < DataGridView1.Rows.Count - 1 Then
            Dim indexString As String = (e.RowIndex + 1).ToString
            Dim sz As SizeF = e.Graphics.MeasureString(indexString, DataGridView1.Font)
            Dim pt As New PointF(e.CellBounds.Width - sz.Width, e.CellBounds.Y + (e.CellBounds.Height / 2 - sz.Height / 2))
            e.Paint(e.ClipBounds, DataGridViewPaintParts.All)
            e.Graphics.DrawString(indexString, DataGridView1.Font, Brushes.Black, pt)
            e.Handled = True
        End If
    End Sub
End Class