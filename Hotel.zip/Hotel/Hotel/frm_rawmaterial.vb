﻿Imports System.Data.OleDb

Public Class frm_rawmaterial

    Private Sub frm_rawmaterial_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        clear()
    End Sub
    Sub clear()
        On Error Resume Next
        cn.Open()
        cmd = New OleDb.OleDbCommand("select * from tb_RawMaterial_info", cn)
        Dim reader As OleDbDataReader = cmd.ExecuteReader
        If (reader.Read = True) Then
            strsql = "select max(Item_Id) from tb_RawMaterial_info"
            cmd = New OleDb.OleDbCommand(strsql, cn)
            oadp = New OleDb.OleDbDataAdapter(cmd)
            otable = New DataTable("tb_RawMaterial_info")
            oadp.Fill(otable)
            row = otable.Rows(0)
            TextBoxrawid.Text = row.Item(0) + 1
        ElseIf (reader.Read = False) Then
            TextBoxrawid.Text = "1"
        End If
        cn.Close()

        TextBoxrawitemname.Text = ""
        TextBoxrawsupp.Text = ""
        TextBoxrawcost.Text = ""
        TextBoxrawcompnm.Text = ""
        TextBoxrawitemname.Focus()
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Buttonsave.Enabled = True
        Buttonshow.Enabled = True
        btnupdate.Enabled = False
        clear()

    End Sub

    Private Sub Buttonsave_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonsave.Click
        On Error Resume Next
        If TextBoxrawitemname.Text = "" Then
            MsgBox("Please enter item name", MsgBoxStyle.OkOnly, "Error")
            TextBoxrawitemname.Focus()
        Else
            cn.Open()
            strsql = "insert into tb_RawMaterial_info values(" & Val(TextBoxrawid.Text) & ",'" & TextBoxrawitemname.Text & "','" & TextBoxrawsupp.Text & "'," & Val(TextBoxrawcost.Text) & ",'" & TextBoxrawcompnm.Text & "',CDate('" & DateTimePickerraw.Text & "'))"
            cmd = New OleDb.OleDbCommand(strsql, cn)
            cmd.ExecuteNonQuery()
            MsgBox("Record is Saved", MsgBoxStyle.DefaultButton1, "Hotel")
            cn.Close()
            clear()
        End If

    End Sub

    Private Sub Buttonshow_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonshow.Click
        frm_rawmaterial_view.Show()
    End Sub

    Private Sub Buttoncancel_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncancel.Click
        Me.Close()
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        On Error Resume Next
        If (MsgBox("Are You Sure", MsgBoxStyle.YesNoCancel, "Hotel") = DialogResult.Yes) Then
            cn.Open()
            strsql = "delete from tb_RawMaterial_info where Item_Id= " & Val(TextBoxrawid.Text) & ""
            cmd = New OleDb.OleDbCommand(strsql, cn)
            cmd.ExecuteNonQuery()
            MsgBox("Record is Deleted", MsgBoxStyle.Information, "Hotel")
            cn.Close()
            clear()
        End If
    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        On Error Resume Next
        cn.Open()
        strsql = "update tb_RawMaterial_info set Item_Name='" & TextBoxrawitemname.Text & "', Supplier_Name='" & TextBoxrawsupp.Text & "',Cost=" & Val(TextBoxrawcost.Text) & ",Company_Name='" & TextBoxrawcompnm.Text & "',Dated=CDate('" & DateTimePickerraw.Text & "') where Item_Id=" & Val(TextBoxrawid.Text) & "  "
        cmd = New OleDb.OleDbCommand(strsql, cn)
        cmd.ExecuteNonQuery()
        MsgBox("Record is Updated", MsgBoxStyle.DefaultButton1, "Hotel")
        cn.Close()
        clear()
    End Sub

    Private Sub DateTimePickerraw_LostFocus(sender As Object, e As EventArgs) Handles DateTimePickerraw.LostFocus
        Buttonsave.Focus()
    End Sub


End Class