﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_material_view
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnshowall = New System.Windows.Forms.Button()
        Me.btnclose = New System.Windows.Forms.Button()
        Me.btnok = New System.Windows.Forms.Button()
        Me.btntype = New System.Windows.Forms.Button()
        Me.btnname = New System.Windows.Forms.Button()
        Me.btnid = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(835, 343)
        Me.DataGridView1.TabIndex = 23
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnshowall)
        Me.Panel1.Controls.Add(Me.btnclose)
        Me.Panel1.Controls.Add(Me.btnok)
        Me.Panel1.Controls.Add(Me.btntype)
        Me.Panel1.Controls.Add(Me.btnname)
        Me.Panel1.Controls.Add(Me.btnid)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 343)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(835, 68)
        Me.Panel1.TabIndex = 22
        '
        'btnshowall
        '
        Me.btnshowall.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnshowall.ForeColor = System.Drawing.Color.Navy
        Me.btnshowall.Location = New System.Drawing.Point(16, 36)
        Me.btnshowall.Name = "btnshowall"
        Me.btnshowall.Size = New System.Drawing.Size(75, 26)
        Me.btnshowall.TabIndex = 3
        Me.btnshowall.Text = "Show &All"
        Me.btnshowall.UseVisualStyleBackColor = True
        '
        'btnclose
        '
        Me.btnclose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclose.ForeColor = System.Drawing.Color.Navy
        Me.btnclose.Location = New System.Drawing.Point(169, 35)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(75, 26)
        Me.btnclose.TabIndex = 5
        Me.btnclose.Text = "&Close"
        Me.btnclose.UseVisualStyleBackColor = True
        '
        'btnok
        '
        Me.btnok.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnok.ForeColor = System.Drawing.Color.Navy
        Me.btnok.Location = New System.Drawing.Point(92, 36)
        Me.btnok.Name = "btnok"
        Me.btnok.Size = New System.Drawing.Size(75, 26)
        Me.btnok.TabIndex = 4
        Me.btnok.Text = "&OK"
        Me.btnok.UseVisualStyleBackColor = True
        '
        'btntype
        '
        Me.btntype.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntype.ForeColor = System.Drawing.Color.Navy
        Me.btntype.Location = New System.Drawing.Point(169, 6)
        Me.btntype.Name = "btntype"
        Me.btntype.Size = New System.Drawing.Size(75, 26)
        Me.btntype.TabIndex = 2
        Me.btntype.Text = "&Type"
        Me.btntype.UseVisualStyleBackColor = True
        '
        'btnname
        '
        Me.btnname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnname.ForeColor = System.Drawing.Color.Navy
        Me.btnname.Location = New System.Drawing.Point(92, 6)
        Me.btnname.Name = "btnname"
        Me.btnname.Size = New System.Drawing.Size(75, 26)
        Me.btnname.TabIndex = 1
        Me.btnname.Text = "Mat &Name"
        Me.btnname.UseVisualStyleBackColor = True
        '
        'btnid
        '
        Me.btnid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnid.ForeColor = System.Drawing.Color.Navy
        Me.btnid.Location = New System.Drawing.Point(16, 6)
        Me.btnid.Name = "btnid"
        Me.btnid.Size = New System.Drawing.Size(75, 26)
        Me.btnid.TabIndex = 0
        Me.btnid.Text = "&Id"
        Me.btnid.UseVisualStyleBackColor = True
        '
        'frm_material_view
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(835, 411)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frm_material_view"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Item Data"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnshowall As System.Windows.Forms.Button
    Friend WithEvents btnclose As System.Windows.Forms.Button
    Friend WithEvents btnok As System.Windows.Forms.Button
    Friend WithEvents btntype As System.Windows.Forms.Button
    Friend WithEvents btnname As System.Windows.Forms.Button
    Friend WithEvents btnid As System.Windows.Forms.Button
End Class
