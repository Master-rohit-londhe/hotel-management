﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_rawmaterial_view
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.btnbynm = New System.Windows.Forms.Button()
        Me.btnshowall = New System.Windows.Forms.Button()
        Me.btnok = New System.Windows.Forms.Button()
        Me.btnclose = New System.Windows.Forms.Button()
        Me.btnbyid = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.DataGridViewraw = New System.Windows.Forms.DataGridView()
        Me.Panel1.SuspendLayout()
        CType(Me.DataGridViewraw, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnbynm
        '
        Me.btnbynm.BackColor = System.Drawing.Color.Transparent
        Me.btnbynm.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnbynm.ForeColor = System.Drawing.Color.Navy
        Me.btnbynm.Location = New System.Drawing.Point(156, 10)
        Me.btnbynm.Name = "btnbynm"
        Me.btnbynm.Size = New System.Drawing.Size(66, 27)
        Me.btnbynm.TabIndex = 20
        Me.btnbynm.Text = "&Name"
        Me.btnbynm.UseVisualStyleBackColor = False
        '
        'btnshowall
        '
        Me.btnshowall.BackColor = System.Drawing.Color.Transparent
        Me.btnshowall.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnshowall.ForeColor = System.Drawing.Color.Navy
        Me.btnshowall.Location = New System.Drawing.Point(12, 43)
        Me.btnshowall.Name = "btnshowall"
        Me.btnshowall.Size = New System.Drawing.Size(66, 27)
        Me.btnshowall.TabIndex = 22
        Me.btnshowall.Text = "Show &All"
        Me.btnshowall.UseVisualStyleBackColor = False
        '
        'btnok
        '
        Me.btnok.BackColor = System.Drawing.Color.Transparent
        Me.btnok.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnok.ForeColor = System.Drawing.Color.Navy
        Me.btnok.Location = New System.Drawing.Point(12, 10)
        Me.btnok.Name = "btnok"
        Me.btnok.Size = New System.Drawing.Size(66, 27)
        Me.btnok.TabIndex = 18
        Me.btnok.Text = "&OK"
        Me.btnok.UseVisualStyleBackColor = False
        '
        'btnclose
        '
        Me.btnclose.BackColor = System.Drawing.Color.Transparent
        Me.btnclose.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclose.ForeColor = System.Drawing.Color.Navy
        Me.btnclose.Location = New System.Drawing.Point(84, 43)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(66, 27)
        Me.btnclose.TabIndex = 21
        Me.btnclose.Text = "&Close"
        Me.btnclose.UseVisualStyleBackColor = False
        '
        'btnbyid
        '
        Me.btnbyid.BackColor = System.Drawing.Color.Transparent
        Me.btnbyid.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnbyid.ForeColor = System.Drawing.Color.Navy
        Me.btnbyid.Location = New System.Drawing.Point(84, 10)
        Me.btnbyid.Name = "btnbyid"
        Me.btnbyid.Size = New System.Drawing.Size(66, 27)
        Me.btnbyid.TabIndex = 19
        Me.btnbyid.Text = "&Id"
        Me.btnbyid.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnbynm)
        Me.Panel1.Controls.Add(Me.btnshowall)
        Me.Panel1.Controls.Add(Me.btnok)
        Me.Panel1.Controls.Add(Me.btnclose)
        Me.Panel1.Controls.Add(Me.btnbyid)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 387)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(684, 75)
        Me.Panel1.TabIndex = 25
        '
        'DataGridViewraw
        '
        Me.DataGridViewraw.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar
        Me.DataGridViewraw.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridViewraw.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewraw.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridViewraw.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewraw.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridViewraw.Location = New System.Drawing.Point(0, 0)
        Me.DataGridViewraw.Name = "DataGridViewraw"
        Me.DataGridViewraw.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridViewraw.Size = New System.Drawing.Size(684, 462)
        Me.DataGridViewraw.TabIndex = 24
        '
        'frm_rawmaterial_view
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(684, 462)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.DataGridViewraw)
        Me.Name = "frm_rawmaterial_view"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Raw Material Data"
        Me.Panel1.ResumeLayout(False)
        CType(Me.DataGridViewraw, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnbynm As System.Windows.Forms.Button
    Friend WithEvents btnshowall As System.Windows.Forms.Button
    Friend WithEvents btnok As System.Windows.Forms.Button
    Friend WithEvents btnclose As System.Windows.Forms.Button
    Friend WithEvents btnbyid As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents DataGridViewraw As System.Windows.Forms.DataGridView
End Class
