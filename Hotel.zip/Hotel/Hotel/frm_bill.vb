﻿Imports System.Data.OleDb

Public Class frm_bill
    Dim cmd, cmd1 As OleDb.OleDbCommand
    Dim strsql As String
    Dim ctr, i As Integer

    Private Sub frm_bill_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F10 Then
            btnPrint.PerformClick()
        End If
      
        
    End Sub

    Private Sub frm_bill_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbcust.Focus()
        clear()
        cmbcust.Focus()

        'add values
        cn.Open()
        cmd = New OleDb.OleDbCommand(strsql, cn)
        cmd.CommandText = "select DISTINCT MatId,MaterialName from tb_material_info order by MatId asc"

        Dim dr7 As OleDbDataReader = cmd.ExecuteReader

        While dr7.Read
            cmbmatid.Items.Add(dr7.Item(0))
            cmbmatnm.Items.Add(dr7.Item(1))
        End While
        dr7.Close()
        cn.Close()

        cn.Open()
        cmd = New OleDb.OleDbCommand(strsql, cn)
        cmd.CommandText = "select DISTINCT CustName from tb_customer_info order by CustName asc"

        Dim dr8 As OleDbDataReader = cmd.ExecuteReader

        While dr8.Read
            cmbcust.Items.Add(dr8.Item(0))
        End While
        dr8.Close()
        cn.Close()
    End Sub
    Sub clear()
        On Error Resume Next
        btnsave.Enabled = True
        btnmodify.Enabled = False
        LinkLabel1.Visible = False
        LinkLabel2.Visible = False
        LinkLabel3.Visible = False
        cmbcust.Text = "Cash Sales"
        dtp.Text = ""
        cmbpaymode.SelectedIndex = 0
        cmbmatid.Text = ""
        cmbmatnm.Text = ""
        txtqty.Text = "1"
        txtrate.Text = ""
        cmbgst.SelectedIndex = 0
        txtgstamt.Text = ""
        txtamt.Text = ""
        txttotamt.Text = ""
        txtsubtotamt.Text = ""
        txtadv.Text = "0"
        txtdisc.Text = "0"
        txtbillamt.Text = ""
        txttotqty.Text = ""
        txtnetamt.Text = ""
        cn.Open()
        cmd = New OleDbCommand("select * from tb_salebill_master", cn)
        Dim reader As OleDbDataReader = cmd.ExecuteReader
        If (reader.Read = True) Then
            strsql = "select max(InvoiceId)from tb_salebill_master"
            cmd = New OleDb.OleDbCommand(strsql, cn)
            oadp = New OleDb.OleDbDataAdapter(cmd)
            otable = New DataTable("tb_salebill_master")
            oadp.Fill(otable)
            row = otable.Rows(0)
            txtno.Text = row.Item(0) + 1
        ElseIf (reader.Read = False) Then
            txtno.Text = "1"
        End If
        cn.Close()
        DataGridView1.Rows.Clear()
        cmbcust.Focus()

       
    End Sub
    Sub caltotalqty()
        Dim total As String = 0.0#
        For i As Integer = 0 To DataGridView1.RowCount - 1
            total += Val(DataGridView1.Rows(i).Cells(2).Value)
        Next
        txttotqty.Text = total
    End Sub
    Sub caltotalamt()
        Dim total As String = 0.0#
        For i As Integer = 0 To DataGridView1.RowCount - 1
            total += Val(DataGridView1.Rows(i).Cells(7).Value)
        Next
        txtsubtotamt.Text = total
    End Sub
    Sub clearfield()
        cmbmatid.Text = ""
        cmbmatnm.Text = ""
        txtqty.Text = "1"
        txtrate.Text = ""
        cmbgst.SelectedIndex = 0
        txtgstamt.Text = ""
        txtamt.Text = ""
        txttotamt.Text = ""
        cmbmatid.Focus()
        caltotalqty()
        caltotalamt()
    End Sub

   

    Private Sub btnnew_Click(sender As Object, e As EventArgs) Handles btnnew.Click
        clear()
    End Sub
    Private Sub txttotamt_Enter(sender As Object, e As EventArgs) Handles txttotamt.Enter
        Dim s() As String = {cmbmatid.Text, cmbmatnm.Text, txtqty.Text, txtrate.Text, cmbgst.Text, txtgstamt.Text, txtamt.Text, txttotamt.Text}
        DataGridView1.Rows.Add(s)
        cmbmatid.Text = ""
        cmbmatnm.Text = ""
        txtqty.Text = "1"
        txtrate.Text = ""
        cmbgst.SelectedIndex = 0
        txtgstamt.Text = ""
        txtamt.Text = ""
        txttotamt.Text = ""
        cmbmatid.Focus()
        caltotalqty()
        caltotalamt()
    End Sub

    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        On Error Resume Next
        cn.Open()
        strsql = "insert into tb_salebill_master values(" & Val(txtno.Text) & ",'" & cmbcust.Text & "',CDate('" & dtp.Text & "'),'" & cmbpaymode.Text & "'," & Val(txtsubtotamt.Text) & "," & Val(txtadv.Text) & "," & Val(txtdisc.Text) & "," & Val(txtbillamt.Text) & "," & Val(txttotqty.Text) & "," & Val(txtnetamt.Text) & ")"
        cmd = New OleDb.OleDbCommand(strsql, cn)
        cmd.ExecuteNonQuery()

        ctr = DataGridView1.Rows.Count
        i = 0
        While i < ctr - 1
            strsql = "insert into tb_salebill_detail values(" & Val(txtno.Text) & "," & DataGridView1.Item(0, i).Value & ",'" & DataGridView1.Item(1, i).Value & "'," & DataGridView1.Item(2, i).Value & "," & DataGridView1.Item(3, i).Value & "," & DataGridView1.Item(4, i).Value & "," & DataGridView1.Item(5, i).Value & "," & DataGridView1.Item(6, i).Value & "," & DataGridView1.Item(7, i).Value & ")"
            cmd1 = New OleDb.OleDbCommand(strsql, cn)
            cmd1.ExecuteNonQuery()
            strsql1 = "update tb_material_info set Quantity=Quantity-" & DataGridView1.Item(2, i).Value & " where MatId=" & DataGridView1.Item(0, i).Value & ""
            cmd2 = New OleDb.OleDbCommand(strsql1, cn)
            cmd2.ExecuteNonQuery()
            i = i + 1
        End While
        MsgBox("Record Is Saved", MsgBoxStyle.DefaultButton2, "Hotel")
        cn.Close()
        btnsave.Enabled = False
        btnmodify.Enabled = True
        LinkLabel1.Visible = False
        LinkLabel2.Visible = False
        LinkLabel3.Visible = False
    End Sub

    Private Sub cmbmatid_TextChanged(sender As Object, e As EventArgs) Handles cmbmatid.TextChanged
        On Error Resume Next
        strsql = "select MaterialName,Price  from tb_material_info where MatId=" & Val(cmbmatid.Text)
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_material_info")
        oadp.Fill(otable)
        If otable.Rows.Count = 0 Then
            'MsgBox("This supplier id Does Not Exist", MsgBoxStyle.DefaultButton2, "Hotel")
            cmbmatnm.Text = ""
        Else
            row = otable.Rows(0)
            cmbmatnm.Text = row.Item(0)
            txtrate.Text = row.Item(1)
        End If
    End Sub

    Private Sub cmbmatnm_TextChanged(sender As Object, e As EventArgs) Handles cmbmatnm.TextChanged
        On Error Resume Next
        strsql = "select MatId,Price  from tb_material_info where MaterialName= '" & cmbmatnm.Text & "' "
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_material_info")
        oadp.Fill(otable)
        If otable.Rows.Count = 0 Then
            'MsgBox("This supplier id Does Not Exist", MsgBoxStyle.DefaultButton2, "Hotel")
            cmbmatid.Text = ""
        Else
            row = otable.Rows(0)
            cmbmatid.Text = row.Item(0)
            txtrate.Text = row.Item(1)
        End If
    End Sub
    Private Sub txtrate_TextChanged(sender As Object, e As EventArgs) Handles txtrate.TextChanged, txtqty.TextChanged, txtamt.TextChanged
        If String.IsNullOrEmpty(txtqty.Text) OrElse String.IsNullOrEmpty(txtrate.Text) Then Exit Sub
        If Not IsNumeric(txtqty.Text) OrElse Not IsNumeric(txtrate.Text) Then Exit Sub
        txtamt.Text = CDbl(txtqty.Text) * CDbl(txtrate.Text)

        If btnmodify.Enabled = True Then
            If Val(txtnewqty.Text) > Val(txtqty.Text) Then
                txtupdateqty.Text = CDbl(txtnewqty.Text) - CDbl(txtqty.Text)
            End If
            If Val(txtqty.Text) > Val(txtnewqty.Text) Then
                txtupdateqty.Text = CDbl(txtqty.Text) - CDbl(txtnewqty.Text)
            End If
        End If
    End Sub

    Private Sub txtgstamt_TextChanged(sender As Object, e As EventArgs) Handles txtgstamt.TextChanged, txtamt.TextChanged, cmbgst.TextChanged, txtqty.TextChanged
        If String.IsNullOrEmpty(txtamt.Text) OrElse String.IsNullOrEmpty(cmbgst.Text) Then Exit Sub
        If Not IsNumeric(txtamt.Text) OrElse Not IsNumeric(cmbgst.Text) Then Exit Sub
        txtgstamt.Text = CDbl(txtamt.Text) * CDbl(cmbgst.Text) / 100
    End Sub

    Private Sub txttotamt_TextChanged(sender As Object, e As EventArgs) Handles txttotamt.TextChanged, txtamt.TextChanged, txtgstamt.TextChanged
        If String.IsNullOrEmpty(txtamt.Text) OrElse String.IsNullOrEmpty(txtgstamt.Text) Then Exit Sub
        If Not IsNumeric(txtamt.Text) OrElse Not IsNumeric(txtgstamt.Text) Then Exit Sub
        txttotamt.Text = CDbl(txtamt.Text) + CDbl(txtgstamt.Text)
    End Sub

    Private Sub txtsubtotamt_TextChanged(sender As Object, e As EventArgs) Handles txtsubtotamt.TextChanged, txtdisc.TextChanged, txtbillamt.TextChanged, txtnetamt.TextChanged, txtadv.TextChanged
        If String.IsNullOrEmpty(txtsubtotamt.Text) OrElse String.IsNullOrEmpty(txtdisc.Text) OrElse String.IsNullOrEmpty(txtadv.Text) Then Exit Sub
        If Not IsNumeric(txtsubtotamt.Text) OrElse Not IsNumeric(txtdisc.Text) OrElse Not IsNumeric(txtadv.Text) Then Exit Sub
        txtbillamt.Text = CDbl(txtsubtotamt.Text) - CDbl(txtdisc.Text) - CDbl(txtadv.Text)
        txtnetamt.Text = CDbl(txtbillamt.Text)
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        clear()
    End Sub
    Private Sub btnview_Click(sender As Object, e As EventArgs) Handles btnview.Click
        frm_bill_view.show()
    End Sub
    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        Dim i As Integer
        Try
            i = DataGridView1.CurrentRow.Index
            Me.cmbmatid.Text = DataGridView1.Item(0, i).Value
            Me.cmbmatnm.Text = DataGridView1.Item(1, i).Value
            Me.txtqty.Text = DataGridView1.Item(2, i).Value
            Me.txtrate.Text = DataGridView1.Item(3, i).Value
            Me.cmbgst.Text = DataGridView1.Item(4, i).Value
            Me.txtgstamt.Text = DataGridView1.Item(5, i).Value
            Me.txtamt.Text = DataGridView1.Item(6, i).Value
            Me.txttotamt.Text = DataGridView1.Item(7, i).Value
        Catch ex As Exception
        End Try
        If btnmodify.Enabled = False Then
            LinkLabel1.Visible = True
            LinkLabel3.Visible = True
        ElseIf btnmodify.Enabled = True Then
            LinkLabel1.Visible = False
            LinkLabel2.Visible = True
            LinkLabel3.Visible = False
        End If
        Me.txtnewqty.Text = DataGridView1.Item(2, i).Value
    End Sub
    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        ' get the index of the selected row
        Dim index As Integer
        index = DataGridView1.CurrentCell.RowIndex

        ' delete the selected row
        DataGridView1.Rows.RemoveAt(index)
        clearfield()
        LinkLabel1.Visible = False
    End Sub

    Private Sub btnmodify_Click(sender As Object, e As EventArgs) Handles btnmodify.Click
        On Error Resume Next
        cn.Open()
        strsql = "update tb_salebill_master set Customer='" & cmbcust.Text & "',Dated=CDate('" & dtp.Text & "'),Paymode='" & cmbpaymode.Text & "',SubtotalAmount=" & Val(txtsubtotamt.Text) & ",Advance=" & Val(txtadv.Text) & ", Discount=" & Val(txtdisc.Text) & ",BillAmt=" & Val(txtbillamt.Text) & ",TotalQty=" & Val(txttotqty.Text) & ",NetAmt=" & Val(txtnetamt.Text) & " where InvoiceId=" & Val(txtno.Text) & " "
        cmd = New OleDb.OleDbCommand(strsql, cn)
        cmd.ExecuteNonQuery()

        ctr = DataGridView1.Rows.Count
        i = 0
        While i < ctr - 1
            strsql = "update tb_salebill_detail set Qty=" & Val(txtqty.Text) & ",Rate=" & Val(txtrate.Text) & ",GST=" & Val(cmbgst.Text) & ",GSTAmt=" & Val(txtgstamt.Text) & ",Amount=" & Val(txtamt.Text) & ",TotalAmt=" & Val(txttotamt.Text) & " where InvoiceId=" & Val(txtno.Text) & " And MatId=" & Val(cmbmatid.Text) & " And  MaterialName='" & cmbmatnm.Text & "'  "
            cmd1 = New OleDb.OleDbCommand(strsql, cn)
            cmd1.ExecuteNonQuery()
            i = i + 1
        End While


        If Val(txtnewqty.Text) > Val(txtqty.Text) Then
            strsql1 = "update tb_material_info set Quantity=Quantity+" & Val(txtupdateqty.Text) & " where MatId=" & Val(cmbmatid.Text) & ""
            cmd2 = New OleDb.OleDbCommand(strsql1, cn)
            cmd2.ExecuteNonQuery()
        End If
        If Val(txtnewqty.Text) < Val(txtqty.Text) Then
            strsql1 = "update tb_material_info set Quantity=Quantity-" & Val(txtupdateqty.Text) & " where MatId=" & Val(cmbmatid.Text) & ""
            cmd2 = New OleDb.OleDbCommand(strsql1, cn)
            cmd2.ExecuteNonQuery()
        End If


        MsgBox("Record Is Updated", MsgBoxStyle.DefaultButton2, "Hotel")
        cn.Close()

        'Search from details table
        DataGridView1.Rows.Clear()
        strsql = "select * from tb_salebill_detail where InvoiceId=" & Val(txtno.Text) & ""
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_salebill_detail")
        oadp.Fill(otable)
        If otable.Rows.Count = 0 Then
            MsgBox("This Details Does Not Exist", MsgBoxStyle.Information, "Hotel")
        Else
            i = 0
            While i < otable.Rows.Count
                row = otable.Rows(i)
                Dim s() As String = {row.Item(1), row.Item(2), row.Item(3), row.Item(4), row.Item(5), row.Item(6), row.Item(7), row.Item(8)}
                DataGridView1.Rows.Add(s)
                i = i + 1
            End While
        End If
        cn.Close()

        caltotalqty()
        caltotalamt()
        LinkLabel1.Visible = False
        LinkLabel2.Visible = False
        LinkLabel3.Visible = False
        cn.Open()
        strsql = "update tb_salebill_master set Customer='" & cmbcust.Text & "',Dated=CDate('" & dtp.Text & "'),Paymode='" & cmbpaymode.Text & "',SubtotalAmount=" & Val(txtsubtotamt.Text) & ",Advance=" & Val(txtadv.Text) & ",Discount=" & Val(txtdisc.Text) & ",BillAmt=" & Val(txtbillamt.Text) & ",TotalQty=" & Val(txttotqty.Text) & ",NetAmt=" & Val(txtnetamt.Text) & " where InvoiceId=" & Val(txtno.Text) & " "
        cmd = New OleDb.OleDbCommand(strsql, cn)
        cmd.ExecuteNonQuery()
        cn.Close()
        clearfield()
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        On Error Resume Next
        If (MsgBox("Are You Sure", MsgBoxStyle.YesNoCancel, "Hotel") = DialogResult.Yes) Then
            cn.Open()
            strsql1 = "delete from tb_salebill_detail where InvoiceId=" & Val(txtno.Text) & "  And MatId=" & Val(cmbmatid.Text) & " And MaterialName='" & cmbmatnm.Text & "'  "
            cmd1 = New OleDb.OleDbCommand(strsql1, cn)
            cmd1.ExecuteNonQuery()
            strsql = "update tb_material_info set Quantity=Quantity+" & Val(txtqty.Text) & " where MatId=" & Val(cmbmatid.Text) & ""
            cmd2 = New OleDb.OleDbCommand(strsql, cn)
            cmd2.ExecuteNonQuery()
            MsgBox("Record is Deleted", MsgBoxStyle.DefaultButton2, "Hotel")
            cn.Close()

            ' get the index of the selected row
            Dim index As Integer
            index = DataGridView1.CurrentCell.RowIndex

            ' delete the selected row
            DataGridView1.Rows.RemoveAt(index)
            clearfield()
            LinkLabel1.Visible = False
            btnmodify.Enabled = True

        End If

        caltotalqty()
        caltotalamt()

        cn.Open()
        strsql = "update tb_salebill_master set Customer='" & cmbcust.Text & "',Dated=CDate('" & dtp.Text & "'),Paymode='" & cmbpaymode.Text & "',SubtotalAmount=" & Val(txtsubtotamt.Text) & ",Advance=" & Val(txtadv.Text) & ",Discount=" & Val(txtdisc.Text) & ",BillAmt=" & Val(txtbillamt.Text) & ",TotalQty=" & Val(txttotqty.Text) & ",NetAmt=" & Val(txtnetamt.Text) & " where InvoiceId=" & Val(txtno.Text) & " "
        cmd = New OleDb.OleDbCommand(strsql, cn)
        cmd.ExecuteNonQuery()
        cn.Close()

        'Search from details table
        DataGridView1.Rows.Clear()
        strsql = "select * from tb_salebill_detail where InvoiceId=" & Val(txtno.Text) & ""
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_salebill_detail")
        oadp.Fill(otable)
        If otable.Rows.Count = 0 Then
            MsgBox("This Details Does Not Exist", MsgBoxStyle.Information, "Hotel")
        Else
            i = 0
            While i < otable.Rows.Count
                row = otable.Rows(i)
                Dim s() As String = {row.Item(1), row.Item(2), row.Item(3), row.Item(4), row.Item(5), row.Item(6), row.Item(7), row.Item(8)}
                DataGridView1.Rows.Add(s)
                i = i + 1
            End While
        End If
        cn.Close()

        LinkLabel1.Visible = False
        LinkLabel2.Visible = False
        LinkLabel3.Visible = False
    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        'On Error Resume Next
        If (MsgBox("Are You Sure", MsgBoxStyle.YesNoCancel, "Hotel") = DialogResult.Yes) Then
            ctr = DataGridView1.Rows.Count
            i = 0
            cn.Open()
            While i < ctr - 1
                strsql = "update tb_material_info set Quantity=Quantity+" & DataGridView1.Item(2, i).Value & " where MatId=" & DataGridView1.Item(0, i).Value & ""
                cmd2 = New OleDb.OleDbCommand(strsql, cn)
                cmd2.ExecuteNonQuery()
                i = i + 1
            End While
            cn.Close()

            cn.Open()
            strsql = "delete from tb_salebill_master where InvoiceId=" & Val(txtno.Text) & ""
            cmd = New OleDb.OleDbCommand(strsql, cn)
            cmd.ExecuteNonQuery()

            strsql1 = "delete from tb_salebill_detail where InvoiceId=" & Val(txtno.Text) & "  "
            cmd1 = New OleDb.OleDbCommand(strsql1, cn)
            cmd1.ExecuteNonQuery()
            MsgBox("Complete Record is Deleted", MsgBoxStyle.Information, "Hotel")
            cn.Close()



            clear()
        End If
        LinkLabel1.Visible = False
        LinkLabel2.Visible = False
        LinkLabel3.Visible = False
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        Dim newDataRow As DataGridViewRow
        Dim index As Integer
        index = DataGridView1.CurrentRow.Index
        newDataRow = DataGridView1.Rows(index)
        newDataRow.Cells(0).Value = cmbmatid.Text
        newDataRow.Cells(1).Value = cmbmatnm.Text
        newDataRow.Cells(2).Value = txtqty.Text
        newDataRow.Cells(3).Value = txtrate.Text
        newDataRow.Cells(4).Value = cmbgst.Text
        newDataRow.Cells(5).Value = txtgstamt.Text
        newDataRow.Cells(6).Value = txtamt.Text
        newDataRow.Cells(7).Value = txttotamt.Text
        cmbmatid.Focus()
        caltotalqty()
        caltotalamt()
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        billreceipt.Show()
    End Sub

   
    Private Sub cmbpaymode_LostFocus(sender As Object, e As EventArgs) Handles cmbpaymode.LostFocus
        cmbmatid.Focus()
    End Sub
End Class