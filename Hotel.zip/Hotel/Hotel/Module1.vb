﻿Module Module1
    Public s As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Hotel\HotelDb.mdb"

    Public cn As New OleDb.OleDbConnection(s)
    Public cmd As OleDb.OleDbCommand
    Public oadp As OleDb.OleDbDataAdapter
    Public otable As DataTable
    Public row As DataRow
    Public strsql, strsql1 As String
    Public cmd1, cmd2 As OleDb.OleDbCommand
    Public ctr, i As Integer
End Module
