﻿Imports System.Data.OleDb

Public Class form_login

    Private Sub form_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbdesignation.SelectedIndex = 0
        txtusername.Select()
        txtusername.Focus()
    End Sub

    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        cn.Open()
        strsql = "SELECT designation, username, password FROM tb_login WHERE designation='" & cmbdesignation.Text & "' AND username='" & txtusername.Text & "' AND password='" & txtpassword.Text & "'"
        cmd = New OleDb.OleDbCommand(strsql, cn)
        Dim dr As OleDbDataReader = cmd.ExecuteReader
        Try
            If dr.Read = False Then
                MessageBox.Show("Authentication failed...")
                Me.Show()
            Else
                MessageBox.Show("Login successfully...")
                frm_main_menu.Show()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        cn.Close()
    End Sub

    Private Sub btnlogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        Me.Close()
    End Sub
End Class
