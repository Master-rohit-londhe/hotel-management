﻿Imports System.Data.OleDb

Public Class frm_customer_view

  

    Private Sub frm_customer_view_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadData()
    End Sub
    Sub loadData()
        On Error Resume Next
        cn.Open()
        Dim strsql As String
        strsql = " select * from tb_customer_info order by CustId asc"
        Dim cmd As OleDbCommand = New OleDbCommand(strsql, cn)
        Dim oadp As OleDbDataAdapter = New OleDb.OleDbDataAdapter(cmd)
        Dim otable As DataTable = New DataTable("tb_customer_info")
        oadp.Fill(otable)
        DataGridView1.DataSource = otable
        cn.Close()
        DataGridView1.Rows(0).Cells(0).Selected = True
        DataGridView1.Select()
    End Sub
    Private Sub DataGridView1_CellPainting(sender As Object, e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        If e.ColumnIndex = -1 AndAlso e.RowIndex > -1 AndAlso e.RowIndex < DataGridView1.Rows.Count - 1 Then
            Dim indexString As String = (e.RowIndex + 1).ToString
            Dim sz As SizeF = e.Graphics.MeasureString(indexString, DataGridView1.Font)
            Dim pt As New PointF(e.CellBounds.Width - sz.Width, e.CellBounds.Y + (e.CellBounds.Height / 2 - sz.Height / 2))
            e.Paint(e.ClipBounds, DataGridViewPaintParts.All)
            e.Graphics.DrawString(indexString, DataGridView1.Font, Brushes.Black, pt)
            e.Handled = True
        End If
    End Sub

    Private Sub btnid_Click(sender As Object, e As EventArgs) Handles btnid.Click
        On Error Resume Next
        Dim id As Double
        cn.Open()
        id = InputBox("Enter Customer Id.", "Hotel")
        strsql = " select * from tb_customer_info where CustId=" & id
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_customer_info")
        oadp.Fill(otable)
        DataGridView1.DataSource = otable
        If otable.Rows.Count = 0 Then
            MsgBox("This Id. Does Not Exist", MsgBoxStyle.DefaultButton1, "Hotel")
        Else
            row = otable.Rows(0)
        End If
        cn.Close()
    End Sub

    Private Sub btnname_Click(sender As Object, e As EventArgs) Handles btnname.Click
        On Error Resume Next
        Dim custName As String
        cn.Open()
        custName = InputBox("Enter Customer Name", "Hotel")
        strsql = " select * from tb_customer_info  where CustName like '%" & custName & "%'"
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_customer_info")
        oadp.Fill(otable)
        DataGridView1.DataSource = otable
        If otable.Rows.Count = 0 Then
            MsgBox("This Customer Name Does Not Exist", MsgBoxStyle.DefaultButton1, "Hotel")
        Else
            row = otable.Rows(0)
        End If
        cn.Close()
    End Sub

    Private Sub btnMob_Click(sender As Object, e As EventArgs) Handles btnMob.Click
        On Error Resume Next
        Dim mobile As Double
        cn.Open()
        mobile = InputBox("Enter Customer Contact No.", "Hotel")
        ''Search From billing Table
        strsql = " select * from tb_customer_info where MobNo=" & mobile
        cmd = New OleDb.OleDbCommand(strsql, cn)
        oadp = New OleDb.OleDbDataAdapter(cmd)
        otable = New DataTable("tb_customer_info")
        oadp.Fill(otable)
        DataGridView1.DataSource = otable
        If otable.Rows.Count = 0 Then
            MsgBox("This Contact No. Does Not Exist", MsgBoxStyle.DefaultButton1, "Hotel")
        Else
            row = otable.Rows(0)
        End If
        cn.Close()
    End Sub

    Private Sub btnshowall_Click(sender As Object, e As EventArgs) Handles btnshowall.Click
        loadData()
    End Sub

    Private Sub btnok_Click(sender As Object, e As EventArgs) Handles btnok.Click
        frm_customer_master.clearfields()
        Dim i As Integer
        Try
            i = DataGridView1.CurrentRow.Index
            frm_customer_master.txtcustomerid.Text = DataGridView1.Item(0, i).Value
            frm_customer_master.dtp.Text = DataGridView1.Item(1, i).Value
            frm_customer_master.txtname.Text = DataGridView1.Item(2, i).Value
            frm_customer_master.txtaddr.Text = DataGridView1.Item(3, i).Value
            frm_customer_master.txtmob.Text = DataGridView1.Item(4, i).Value
            frm_customer_master.txtgstno.Text = DataGridView1.Item(5, i).Value
            frm_customer_master.cmbtype.Text = DataGridView1.Item(6, i).Value
            frm_customer_master.txtdetails.Text = DataGridView1.Item(7, i).Value
        Catch ex As Exception

        End Try
        frm_customer_master.Show()
        frm_customer_master.btnmodify.Enabled = True
        frm_customer_master.btnsave.Enabled = False
        frm_customer_master.btndelete.Enabled = True
        Me.Close()
    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
    End Sub
End Class