﻿Imports System.Data.OleDb

Public Class frm_material

    Private Sub frm_material_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        clear()
    End Sub

    Private Sub txttotamt_LostFocus(sender As Object, e As EventArgs) Handles txttotamt.LostFocus
        btnsave.Focus()
    End Sub
    Sub clear()
        On Error Resume Next
        btnsave.Enabled = True
        btnmodify.Enabled = False
        dtp.Text = ""
        cmbtype.Text = ""
        txtname.Text = ""
        txtmatnm1.Text = ""
        cmbcat.Text = ""
        txtprice.Text = ""
        txtqty.Text = ""
        cmbunit.Text = ""
        txttotamt.Text = ""
        dtp.Focus()
        cn.Open()
        cmd = New OleDb.OleDbCommand("select * from tb_material_info", cn)
        Dim reader As OleDbDataReader = cmd.ExecuteReader
        If (reader.Read = True) Then
            strsql = "select max(MatId) from tb_material_info"
            cmd = New OleDb.OleDbCommand(strsql, cn)
            oadp = New OleDb.OleDbDataAdapter(cmd)
            otable = New DataTable("tb_material_info")
            oadp.Fill(otable)
            row = otable.Rows(0)
            txtid.Text = row.Item(0) + 1
        ElseIf (reader.Read = False) Then
            txtid.Text = "1"
        End If
        cn.Close()

       
    End Sub
    Sub generateID()
        cn.Open()
        cmd = New OleDb.OleDbCommand("select * from tb_material_info", cn)
        Dim reader As OleDbDataReader = cmd.ExecuteReader
        If (reader.Read = True) Then
            strsql = "select max(MatId)from tb_material_info"
            cmd = New OleDb.OleDbCommand(strsql, cn)
            oadp = New OleDb.OleDbDataAdapter(cmd)
            otable = New DataTable("tb_material_info")
            oadp.Fill(otable)
            row = otable.Rows(0)
            txtid.Text = row.Item(0) + 1
        ElseIf (reader.Read = False) Then
            txtid.Text = "1"
        End If
        cn.Close()
        dtp.Focus()
    End Sub
    Sub clearfields()
        txtid.Text = ""
        dtp.Text = ""
        cmbtype.Text = ""
        txtname.Text = ""
        txtmatnm1.Text = ""
        cmbcat.Text = ""
        txtprice.Text = ""
        txtqty.Text = ""
        cmbunit.Text = ""
        txttotamt.Text = ""
    End Sub

    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        On Error Resume Next
        cn.Open()
        If txtname.Text = "" Then
            MsgBox("Please enter name", MsgBoxStyle.OkOnly, "Error")
            txtname.Focus()
        Else
            strsql = "SELECT * FROM tb_material_info WHERE MaterialName ='" & txtname.Text & "'"
            cmd = New OleDbCommand(strsql, cn)
            Dim dr As OleDbDataReader
            dr = cmd.ExecuteReader()
            If Not dr.HasRows Then
                strsql = "insert into tb_material_info values(" & Val(txtid.Text) & ",CDate('" & dtp.Text & "'),'" & cmbtype.Text & "','" & txtname.Text & "','" & txtmatnm1.Text & "','" & cmbcat.Text & "'," & Val(txtprice.Text) & "," & Val(txtqty.Text) & ",'" & cmbunit.Text & "','" & txttotamt.Text & "')"
                cmd = New OleDb.OleDbCommand(strsql, cn)
                cmd.ExecuteNonQuery()
                MsgBox("Record is Saved", MsgBoxStyle.DefaultButton1, "Hotel")
                clear()
            Else
                MsgBox("This name already exist...Use another name")
                txtname.Focus()
            End If
        End If
        cn.Close()
        generateID()



    End Sub

    Private Sub btnnew_Click(sender As Object, e As EventArgs) Handles btnnew.Click
        clear()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        clear()
    End Sub

    Private Sub btnview_Click(sender As Object, e As EventArgs) Handles btnview.Click
        frm_material_view.show()
    End Sub

    Private Sub btnmodify_Click(sender As Object, e As EventArgs) Handles btnmodify.Click
        On Error Resume Next
        cn.Open()
        strsql = "update [tb_material_info] set [Dated]=CDate('" & dtp.Text & "'), [Type]='" & cmbtype.Text & "',[MaterialName]='" & txtname.Text & "',[MaterialName1]='" & txtmatnm1.Text & "',[Category]='" & cmbcat.Text & "',[Price]=" & Val(txtprice.Text) & ",[Quantity]=" & Val(txtqty.Text) & ",[Unit]='" & cmbunit.Text & "',[TotalAmt]=" & Val(txttotamt.Text) & " where [MatId]=" & Val(txtid.Text) & "  "
        cmd = New OleDb.OleDbCommand(strsql, cn)
        cmd.ExecuteNonQuery()
        MsgBox("Record is Updated", MsgBoxStyle.DefaultButton1, "Hotel")
        cn.Close()
        clear()
    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        On Error Resume Next
        If (MsgBox("Are You Sure", MsgBoxStyle.YesNoCancel, "Hotel") = DialogResult.Yes) Then
            cn.Open()
            strsql = "delete from tb_material_info where MatId=" & Val(txtid.Text) & ""
            cmd = New OleDb.OleDbCommand(strsql, cn)
            cmd.ExecuteNonQuery()
            MsgBox("Record is Deleted", MsgBoxStyle.Information, "Hotel")
            cn.Close()
            clear()
        End If
    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
    End Sub

    Private Sub txtprice_TextChanged(sender As Object, e As EventArgs) Handles txtprice.TextChanged, txtqty.TextChanged, txttotamt.TextChanged
        If String.IsNullOrEmpty(txtprice.Text) OrElse String.IsNullOrEmpty(txtqty.Text) Then Exit Sub
        If Not IsNumeric(txtprice.Text) OrElse Not IsNumeric(txtqty.Text) Then Exit Sub
        txttotamt.Text = CDbl(txtprice.Text) * CDbl(txtqty.Text)
    End Sub

   
End Class