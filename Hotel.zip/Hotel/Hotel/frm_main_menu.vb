﻿Public Class frm_main_menu

    Private Sub CustomerMasterToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CustomerMasterToolStripMenuItem.Click
        frm_customer_master.show()
    End Sub

   
    Private Sub SupplierMasterToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SupplierMasterToolStripMenuItem.Click
        frm_newuser.show()
    End Sub

    Private Sub MaierialMasterToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MaierialMasterToolStripMenuItem.Click
        frm_material.Show()
    End Sub

    Private Sub RawMaterialToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RawMaterialToolStripMenuItem.Click
        frm_rawmaterial.show()
    End Sub

    Private Sub ChangePasswordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangePasswordToolStripMenuItem.Click
        frm_changepass.show()
    End Sub

    Private Sub CalculatorToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles CalculatorToolStripMenuItem1.Click
        System.Diagnostics.Process.Start("calc")
    End Sub

 

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub TToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TToolStripMenuItem.Click
        frm_bill.show()
    End Sub

    Private Sub CustomerReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CustomerReportToolStripMenuItem.Click
        CustomerReport.Show()
    End Sub

    Private Sub NotepadToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NotepadToolStripMenuItem.Click
        System.Diagnostics.Process.Start("notepad")
    End Sub

    Private Sub MaterialReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MaterialReportToolStripMenuItem.Click
        MaterialReport.show()
    End Sub

    Private Sub RawMaterialReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RawMaterialReportToolStripMenuItem.Click
        RawMaterialReport.show()
    End Sub
End Class