﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_bill
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gb1 = New System.Windows.Forms.GroupBox()
        Me.txtupdateqty = New System.Windows.Forms.TextBox()
        Me.txtnewqty = New System.Windows.Forms.TextBox()
        Me.LinkLabel3 = New System.Windows.Forms.LinkLabel()
        Me.cmbgst = New System.Windows.Forms.ComboBox()
        Me.cmbmatid = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtgstamt = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtamt = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtqty = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txttotamt = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtrate = New System.Windows.Forms.TextBox()
        Me.cmbmatnm = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cmbpaymode = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.cmbcust = New System.Windows.Forms.ComboBox()
        Me.dtp = New System.Windows.Forms.DateTimePicker()
        Me.A = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtno = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtadv = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.btnmodify = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtnetamt = New System.Windows.Forms.TextBox()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.txttotqty = New System.Windows.Forms.TextBox()
        Me.btndelete = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.btnview = New System.Windows.Forms.Button()
        Me.txtdisc = New System.Windows.Forms.TextBox()
        Me.btnnew = New System.Windows.Forms.Button()
        Me.txtbillamt = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtsubtotamt = New System.Windows.Forms.TextBox()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.pnlTotalAmt = New System.Windows.Forms.Panel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.MatId = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MaterialName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Qty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Rate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GST = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GSTAmt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Amount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalAmt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gb1.SuspendLayout()
        Me.pnlTotalAmt.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gb1
        '
        Me.gb1.Controls.Add(Me.txtupdateqty)
        Me.gb1.Controls.Add(Me.txtnewqty)
        Me.gb1.Controls.Add(Me.LinkLabel3)
        Me.gb1.Controls.Add(Me.cmbgst)
        Me.gb1.Controls.Add(Me.cmbmatid)
        Me.gb1.Controls.Add(Me.Label5)
        Me.gb1.Controls.Add(Me.Label22)
        Me.gb1.Controls.Add(Me.Label13)
        Me.gb1.Controls.Add(Me.txtgstamt)
        Me.gb1.Controls.Add(Me.Label15)
        Me.gb1.Controls.Add(Me.txtamt)
        Me.gb1.Controls.Add(Me.Label12)
        Me.gb1.Controls.Add(Me.txtqty)
        Me.gb1.Controls.Add(Me.Label6)
        Me.gb1.Controls.Add(Me.txttotamt)
        Me.gb1.Controls.Add(Me.Label7)
        Me.gb1.Controls.Add(Me.txtrate)
        Me.gb1.Controls.Add(Me.cmbmatnm)
        Me.gb1.Controls.Add(Me.Label11)
        Me.gb1.Location = New System.Drawing.Point(25, 67)
        Me.gb1.Margin = New System.Windows.Forms.Padding(4)
        Me.gb1.Name = "gb1"
        Me.gb1.Padding = New System.Windows.Forms.Padding(4)
        Me.gb1.Size = New System.Drawing.Size(1170, 92)
        Me.gb1.TabIndex = 181
        Me.gb1.TabStop = False
        '
        'txtupdateqty
        '
        Me.txtupdateqty.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtupdateqty.Location = New System.Drawing.Point(586, 65)
        Me.txtupdateqty.Name = "txtupdateqty"
        Me.txtupdateqty.Size = New System.Drawing.Size(89, 22)
        Me.txtupdateqty.TabIndex = 172
        Me.txtupdateqty.Visible = False
        '
        'txtnewqty
        '
        Me.txtnewqty.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnewqty.Location = New System.Drawing.Point(480, 66)
        Me.txtnewqty.Name = "txtnewqty"
        Me.txtnewqty.Size = New System.Drawing.Size(89, 22)
        Me.txtnewqty.TabIndex = 172
        Me.txtnewqty.Visible = False
        '
        'LinkLabel3
        '
        Me.LinkLabel3.AutoSize = True
        Me.LinkLabel3.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel3.LinkColor = System.Drawing.Color.Navy
        Me.LinkLabel3.Location = New System.Drawing.Point(697, 63)
        Me.LinkLabel3.Name = "LinkLabel3"
        Me.LinkLabel3.Size = New System.Drawing.Size(83, 17)
        Me.LinkLabel3.TabIndex = 162
        Me.LinkLabel3.TabStop = True
        Me.LinkLabel3.Text = "Update Row"
        Me.LinkLabel3.Visible = False
        '
        'cmbgst
        '
        Me.cmbgst.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbgst.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbgst.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbgst.FormattingEnabled = True
        Me.cmbgst.Items.AddRange(New Object() {"0", "5", "12", "18", "28"})
        Me.cmbgst.Location = New System.Drawing.Point(691, 35)
        Me.cmbgst.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbgst.Name = "cmbgst"
        Me.cmbgst.Size = New System.Drawing.Size(90, 24)
        Me.cmbgst.TabIndex = 168
        '
        'cmbmatid
        '
        Me.cmbmatid.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cmbmatid.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbmatid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbmatid.FormattingEnabled = True
        Me.cmbmatid.Location = New System.Drawing.Point(8, 35)
        Me.cmbmatid.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbmatid.Name = "cmbmatid"
        Me.cmbmatid.Size = New System.Drawing.Size(103, 24)
        Me.cmbmatid.TabIndex = 164
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Navy
        Me.Label5.Location = New System.Drawing.Point(34, 16)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 16)
        Me.Label5.TabIndex = 124
        Me.Label5.Text = "Item Id"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Navy
        Me.Label22.Location = New System.Drawing.Point(704, 15)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(51, 16)
        Me.Label22.TabIndex = 122
        Me.Label22.Text = "GST %"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Navy
        Me.Label13.Location = New System.Drawing.Point(802, 15)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(62, 16)
        Me.Label13.TabIndex = 121
        Me.Label13.Text = "GST Amt"
        '
        'txtgstamt
        '
        Me.txtgstamt.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtgstamt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgstamt.Location = New System.Drawing.Point(797, 35)
        Me.txtgstamt.Margin = New System.Windows.Forms.Padding(4)
        Me.txtgstamt.Name = "txtgstamt"
        Me.txtgstamt.Size = New System.Drawing.Size(90, 22)
        Me.txtgstamt.TabIndex = 169
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Navy
        Me.Label15.Location = New System.Drawing.Point(915, 15)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(53, 16)
        Me.Label15.TabIndex = 100
        Me.Label15.Text = "Amount"
        '
        'txtamt
        '
        Me.txtamt.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtamt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtamt.Location = New System.Drawing.Point(903, 35)
        Me.txtamt.Margin = New System.Windows.Forms.Padding(4)
        Me.txtamt.Name = "txtamt"
        Me.txtamt.Size = New System.Drawing.Size(90, 22)
        Me.txtamt.TabIndex = 170
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Navy
        Me.Label12.Location = New System.Drawing.Point(503, 17)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(36, 16)
        Me.Label12.TabIndex = 78
        Me.Label12.Text = "QTY"
        '
        'txtqty
        '
        Me.txtqty.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtqty.Location = New System.Drawing.Point(479, 37)
        Me.txtqty.Margin = New System.Windows.Forms.Padding(4)
        Me.txtqty.Name = "txtqty"
        Me.txtqty.Size = New System.Drawing.Size(90, 22)
        Me.txtqty.TabIndex = 166
        Me.txtqty.Text = "1"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Navy
        Me.Label6.Location = New System.Drawing.Point(1025, 15)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 16)
        Me.Label6.TabIndex = 62
        Me.Label6.Text = "Total Amt"
        '
        'txttotamt
        '
        Me.txttotamt.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txttotamt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttotamt.Location = New System.Drawing.Point(1009, 35)
        Me.txttotamt.Margin = New System.Windows.Forms.Padding(4)
        Me.txttotamt.Name = "txttotamt"
        Me.txttotamt.Size = New System.Drawing.Size(117, 22)
        Me.txttotamt.TabIndex = 171
        Me.txttotamt.Text = " "
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Navy
        Me.Label7.Location = New System.Drawing.Point(605, 16)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(37, 16)
        Me.Label7.TabIndex = 61
        Me.Label7.Text = "Rate"
        '
        'txtrate
        '
        Me.txtrate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrate.Location = New System.Drawing.Point(585, 36)
        Me.txtrate.Margin = New System.Windows.Forms.Padding(4)
        Me.txtrate.Name = "txtrate"
        Me.txtrate.Size = New System.Drawing.Size(90, 22)
        Me.txtrate.TabIndex = 167
        '
        'cmbmatnm
        '
        Me.cmbmatnm.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cmbmatnm.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbmatnm.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbmatnm.FormattingEnabled = True
        Me.cmbmatnm.Location = New System.Drawing.Point(126, 35)
        Me.cmbmatnm.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbmatnm.Name = "cmbmatnm"
        Me.cmbmatnm.Size = New System.Drawing.Size(330, 24)
        Me.cmbmatnm.TabIndex = 165
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Navy
        Me.Label11.Location = New System.Drawing.Point(221, 15)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(82, 16)
        Me.Label11.TabIndex = 59
        Me.Label11.Text = "ITEM NAME"
        '
        'cmbpaymode
        '
        Me.cmbpaymode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbpaymode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbpaymode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbpaymode.FormattingEnabled = True
        Me.cmbpaymode.Items.AddRange(New Object() {"Cash", "Credit"})
        Me.cmbpaymode.Location = New System.Drawing.Point(975, 17)
        Me.cmbpaymode.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbpaymode.Name = "cmbpaymode"
        Me.cmbpaymode.Size = New System.Drawing.Size(141, 24)
        Me.cmbpaymode.TabIndex = 168
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Navy
        Me.Label10.Location = New System.Drawing.Point(903, 20)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(70, 16)
        Me.Label10.TabIndex = 174
        Me.Label10.Text = "PayMode:"
        '
        'cmbcust
        '
        Me.cmbcust.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbcust.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbcust.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbcust.FormattingEnabled = True
        Me.cmbcust.Location = New System.Drawing.Point(342, 17)
        Me.cmbcust.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbcust.Name = "cmbcust"
        Me.cmbcust.Size = New System.Drawing.Size(266, 24)
        Me.cmbcust.TabIndex = 166
        '
        'dtp
        '
        Me.dtp.CustomFormat = "dd-MMM-yyy"
        Me.dtp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtp.Location = New System.Drawing.Point(727, 18)
        Me.dtp.Margin = New System.Windows.Forms.Padding(4)
        Me.dtp.Name = "dtp"
        Me.dtp.Size = New System.Drawing.Size(131, 22)
        Me.dtp.TabIndex = 167
        '
        'A
        '
        Me.A.AutoSize = True
        Me.A.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.A.ForeColor = System.Drawing.Color.Navy
        Me.A.Location = New System.Drawing.Point(679, 19)
        Me.A.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.A.Name = "A"
        Me.A.Size = New System.Drawing.Size(40, 16)
        Me.A.TabIndex = 173
        Me.A.Text = "Date:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Navy
        Me.Label2.Location = New System.Drawing.Point(271, 20)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(68, 16)
        Me.Label2.TabIndex = 172
        Me.Label2.Text = "Customer:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Navy
        Me.Label1.Location = New System.Drawing.Point(35, 20)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 16)
        Me.Label1.TabIndex = 171
        Me.Label1.Text = "Invoice No:"
        '
        'txtno
        '
        Me.txtno.BackColor = System.Drawing.SystemColors.Control
        Me.txtno.Enabled = False
        Me.txtno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtno.Location = New System.Drawing.Point(117, 17)
        Me.txtno.Margin = New System.Windows.Forms.Padding(4)
        Me.txtno.Name = "txtno"
        Me.txtno.ReadOnly = True
        Me.txtno.Size = New System.Drawing.Size(129, 22)
        Me.txtno.TabIndex = 165
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.Navy
        Me.Label25.Location = New System.Drawing.Point(704, 39)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(68, 16)
        Me.Label25.TabIndex = 181
        Me.Label25.Text = "Advance :"
        '
        'txtadv
        '
        Me.txtadv.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtadv.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtadv.ForeColor = System.Drawing.Color.Red
        Me.txtadv.Location = New System.Drawing.Point(779, 35)
        Me.txtadv.Margin = New System.Windows.Forms.Padding(4)
        Me.txtadv.Multiline = True
        Me.txtadv.Name = "txtadv"
        Me.txtadv.Size = New System.Drawing.Size(96, 24)
        Me.txtadv.TabIndex = 16
        Me.txtadv.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "0"
        Me.txtadv.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(486, 42)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(103, 30)
        Me.Label20.TabIndex = 133
        Me.Label20.Text = "This Deletes " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Complete Record"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnclear
        '
        Me.btnclear.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclear.ForeColor = System.Drawing.Color.Navy
        Me.btnclear.Location = New System.Drawing.Point(210, 10)
        Me.btnclear.Margin = New System.Windows.Forms.Padding(4)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(85, 28)
        Me.btnclear.TabIndex = 173
        Me.btnclear.Text = "Clea&r"
        Me.btnclear.UseVisualStyleBackColor = True
        '
        'btnsave
        '
        Me.btnsave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.ForeColor = System.Drawing.Color.Navy
        Me.btnsave.Location = New System.Drawing.Point(117, 10)
        Me.btnsave.Margin = New System.Windows.Forms.Padding(4)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(85, 28)
        Me.btnsave.TabIndex = 172
        Me.btnsave.Text = "&Save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'btnmodify
        '
        Me.btnmodify.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnmodify.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmodify.ForeColor = System.Drawing.Color.Navy
        Me.btnmodify.Location = New System.Drawing.Point(396, 10)
        Me.btnmodify.Margin = New System.Windows.Forms.Padding(4)
        Me.btnmodify.Name = "btnmodify"
        Me.btnmodify.Size = New System.Drawing.Size(85, 28)
        Me.btnmodify.TabIndex = 175
        Me.btnmodify.Text = "&Modify"
        Me.btnmodify.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Navy
        Me.Label14.Location = New System.Drawing.Point(914, 78)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(83, 16)
        Me.Label14.TabIndex = 131
        Me.Label14.Text = "Net Amount :"
        '
        'txtnetamt
        '
        Me.txtnetamt.BackColor = System.Drawing.SystemColors.Window
        Me.txtnetamt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnetamt.ForeColor = System.Drawing.Color.Red
        Me.txtnetamt.Location = New System.Drawing.Point(1001, 60)
        Me.txtnetamt.Margin = New System.Windows.Forms.Padding(4)
        Me.txtnetamt.Multiline = True
        Me.txtnetamt.Name = "txtnetamt"
        Me.txtnetamt.ReadOnly = True
        Me.txtnetamt.Size = New System.Drawing.Size(111, 37)
        Me.txtnetamt.TabIndex = 19
        '
        'btnPrint
        '
        Me.btnPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrint.ForeColor = System.Drawing.Color.Navy
        Me.btnPrint.Location = New System.Drawing.Point(25, 46)
        Me.btnPrint.Margin = New System.Windows.Forms.Padding(4)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(85, 28)
        Me.btnPrint.TabIndex = 177
        Me.btnPrint.Text = "&Print"
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.Location = New System.Drawing.Point(117, 46)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(85, 28)
        Me.btnClose.TabIndex = 178
        Me.btnClose.Text = "&Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'txttotqty
        '
        Me.txttotqty.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txttotqty.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttotqty.ForeColor = System.Drawing.Color.Red
        Me.txttotqty.Location = New System.Drawing.Point(1012, 30)
        Me.txttotqty.Margin = New System.Windows.Forms.Padding(4)
        Me.txttotqty.Multiline = True
        Me.txttotqty.Name = "txttotqty"
        Me.txttotqty.Size = New System.Drawing.Size(83, 24)
        Me.txttotqty.TabIndex = 18
        Me.txttotqty.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.txttotqty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btndelete
        '
        Me.btndelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndelete.ForeColor = System.Drawing.Color.Navy
        Me.btndelete.Location = New System.Drawing.Point(489, 10)
        Me.btndelete.Margin = New System.Windows.Forms.Padding(4)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(85, 28)
        Me.btndelete.TabIndex = 176
        Me.btndelete.Text = " &Delete"
        Me.btndelete.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Navy
        Me.Label19.Location = New System.Drawing.Point(1016, 11)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(70, 16)
        Me.Label19.TabIndex = 101
        Me.Label19.Text = "Total QTY"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Navy
        Me.Label17.Location = New System.Drawing.Point(706, 68)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(66, 16)
        Me.Label17.TabIndex = 99
        Me.Label17.Text = "Discount :"
        '
        'btnview
        '
        Me.btnview.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnview.ForeColor = System.Drawing.Color.Navy
        Me.btnview.Location = New System.Drawing.Point(303, 10)
        Me.btnview.Margin = New System.Windows.Forms.Padding(4)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(85, 28)
        Me.btnview.TabIndex = 174
        Me.btnview.Text = "&View..."
        Me.btnview.UseVisualStyleBackColor = True
        '
        'txtdisc
        '
        Me.txtdisc.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtdisc.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdisc.ForeColor = System.Drawing.Color.Red
        Me.txtdisc.Location = New System.Drawing.Point(780, 64)
        Me.txtdisc.Margin = New System.Windows.Forms.Padding(4)
        Me.txtdisc.Multiline = True
        Me.txtdisc.Name = "txtdisc"
        Me.txtdisc.Size = New System.Drawing.Size(96, 24)
        Me.txtdisc.TabIndex = 16
        Me.txtdisc.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "0"
        Me.txtdisc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnnew
        '
        Me.btnnew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnew.ForeColor = System.Drawing.Color.Navy
        Me.btnnew.Location = New System.Drawing.Point(24, 10)
        Me.btnnew.Margin = New System.Windows.Forms.Padding(4)
        Me.btnnew.Name = "btnnew"
        Me.btnnew.Size = New System.Drawing.Size(85, 28)
        Me.btnnew.TabIndex = 20
        Me.btnnew.Text = "&New"
        Me.btnnew.UseVisualStyleBackColor = True
        '
        'txtbillamt
        '
        Me.txtbillamt.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtbillamt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbillamt.ForeColor = System.Drawing.Color.Red
        Me.txtbillamt.Location = New System.Drawing.Point(780, 94)
        Me.txtbillamt.Margin = New System.Windows.Forms.Padding(4)
        Me.txtbillamt.Multiline = True
        Me.txtbillamt.Name = "txtbillamt"
        Me.txtbillamt.Size = New System.Drawing.Size(96, 24)
        Me.txtbillamt.TabIndex = 17
        Me.txtbillamt.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.txtbillamt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Navy
        Me.Label18.Location = New System.Drawing.Point(652, 14)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(120, 16)
        Me.Label18.TabIndex = 95
        Me.Label18.Text = "Sub Total Amount :"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Navy
        Me.Label16.Location = New System.Drawing.Point(692, 98)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(80, 16)
        Me.Label16.TabIndex = 97
        Me.Label16.Text = "Bill Amount :"
        '
        'txtsubtotamt
        '
        Me.txtsubtotamt.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtsubtotamt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsubtotamt.ForeColor = System.Drawing.Color.Red
        Me.txtsubtotamt.Location = New System.Drawing.Point(780, 6)
        Me.txtsubtotamt.Margin = New System.Windows.Forms.Padding(4)
        Me.txtsubtotamt.Multiline = True
        Me.txtsubtotamt.Name = "txtsubtotamt"
        Me.txtsubtotamt.Size = New System.Drawing.Size(96, 24)
        Me.txtsubtotamt.TabIndex = 15
        Me.txtsubtotamt.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.txtsubtotamt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel2.LinkColor = System.Drawing.Color.Navy
        Me.LinkLabel2.Location = New System.Drawing.Point(1198, 250)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(94, 17)
        Me.LinkLabel2.TabIndex = 179
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Delete Record"
        Me.LinkLabel2.Visible = False
        '
        'pnlTotalAmt
        '
        Me.pnlTotalAmt.BackColor = System.Drawing.SystemColors.ControlLight
        Me.pnlTotalAmt.Controls.Add(Me.Label25)
        Me.pnlTotalAmt.Controls.Add(Me.txtadv)
        Me.pnlTotalAmt.Controls.Add(Me.Label20)
        Me.pnlTotalAmt.Controls.Add(Me.btnclear)
        Me.pnlTotalAmt.Controls.Add(Me.btnsave)
        Me.pnlTotalAmt.Controls.Add(Me.btnmodify)
        Me.pnlTotalAmt.Controls.Add(Me.Label14)
        Me.pnlTotalAmt.Controls.Add(Me.txtnetamt)
        Me.pnlTotalAmt.Controls.Add(Me.btnPrint)
        Me.pnlTotalAmt.Controls.Add(Me.btnClose)
        Me.pnlTotalAmt.Controls.Add(Me.txttotqty)
        Me.pnlTotalAmt.Controls.Add(Me.btndelete)
        Me.pnlTotalAmt.Controls.Add(Me.Label19)
        Me.pnlTotalAmt.Controls.Add(Me.Label17)
        Me.pnlTotalAmt.Controls.Add(Me.btnview)
        Me.pnlTotalAmt.Controls.Add(Me.txtdisc)
        Me.pnlTotalAmt.Controls.Add(Me.btnnew)
        Me.pnlTotalAmt.Controls.Add(Me.txtbillamt)
        Me.pnlTotalAmt.Controls.Add(Me.Label18)
        Me.pnlTotalAmt.Controls.Add(Me.Label16)
        Me.pnlTotalAmt.Controls.Add(Me.txtsubtotamt)
        Me.pnlTotalAmt.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlTotalAmt.Location = New System.Drawing.Point(0, 573)
        Me.pnlTotalAmt.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlTotalAmt.Name = "pnlTotalAmt"
        Me.pnlTotalAmt.Size = New System.Drawing.Size(1346, 125)
        Me.pnlTotalAmt.TabIndex = 170
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.LinkColor = System.Drawing.Color.Navy
        Me.LinkLabel1.Location = New System.Drawing.Point(1198, 220)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(79, 17)
        Me.LinkLabel1.TabIndex = 178
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Delete Row"
        Me.LinkLabel1.Visible = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.MatId, Me.MaterialName, Me.Qty, Me.Rate, Me.GST, Me.GSTAmt, Me.Amount, Me.TotalAmt})
        Me.DataGridView1.Location = New System.Drawing.Point(22, 181)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(1170, 387)
        Me.DataGridView1.TabIndex = 175
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.SystemColors.Info
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.MediumBlue
        Me.Label9.Location = New System.Drawing.Point(1270, 1)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(74, 14)
        Me.Label9.TabIndex = 176
        Me.Label9.Text = "Alt+R - Clear"
        '
        'MatId
        '
        Me.MatId.HeaderText = "Item Id"
        Me.MatId.Name = "MatId"
        '
        'MaterialName
        '
        Me.MaterialName.HeaderText = "Item Name"
        Me.MaterialName.Name = "MaterialName"
        '
        'Qty
        '
        Me.Qty.HeaderText = "Qty"
        Me.Qty.Name = "Qty"
        '
        'Rate
        '
        Me.Rate.HeaderText = "Rate"
        Me.Rate.Name = "Rate"
        '
        'GST
        '
        Me.GST.HeaderText = "GST"
        Me.GST.Name = "GST"
        '
        'GSTAmt
        '
        Me.GSTAmt.HeaderText = "GST Amt"
        Me.GSTAmt.Name = "GSTAmt"
        '
        'Amount
        '
        Me.Amount.HeaderText = "Amount"
        Me.Amount.Name = "Amount"
        '
        'TotalAmt
        '
        Me.TotalAmt.HeaderText = "Total Amount"
        Me.TotalAmt.Name = "TotalAmt"
        '
        'frm_bill
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1346, 698)
        Me.Controls.Add(Me.gb1)
        Me.Controls.Add(Me.cmbpaymode)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.cmbcust)
        Me.Controls.Add(Me.dtp)
        Me.Controls.Add(Me.A)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtno)
        Me.Controls.Add(Me.LinkLabel2)
        Me.Controls.Add(Me.pnlTotalAmt)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label9)
        Me.Name = "frm_bill"
        Me.Text = "Bill"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.gb1.ResumeLayout(False)
        Me.gb1.PerformLayout()
        Me.pnlTotalAmt.ResumeLayout(False)
        Me.pnlTotalAmt.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents gb1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtupdateqty As System.Windows.Forms.TextBox
    Friend WithEvents txtnewqty As System.Windows.Forms.TextBox
    Friend WithEvents LinkLabel3 As System.Windows.Forms.LinkLabel
    Friend WithEvents cmbgst As System.Windows.Forms.ComboBox
    Friend WithEvents cmbmatid As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtgstamt As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtamt As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtqty As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txttotamt As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtrate As System.Windows.Forms.TextBox
    Friend WithEvents cmbmatnm As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cmbpaymode As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents cmbcust As System.Windows.Forms.ComboBox
    Friend WithEvents dtp As System.Windows.Forms.DateTimePicker
    Friend WithEvents A As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtno As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtadv As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents btnclear As System.Windows.Forms.Button
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents btnmodify As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtnetamt As System.Windows.Forms.TextBox
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents txttotqty As System.Windows.Forms.TextBox
    Friend WithEvents btndelete As System.Windows.Forms.Button
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents btnview As System.Windows.Forms.Button
    Friend WithEvents txtdisc As System.Windows.Forms.TextBox
    Friend WithEvents btnnew As System.Windows.Forms.Button
    Friend WithEvents txtbillamt As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtsubtotamt As System.Windows.Forms.TextBox
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents pnlTotalAmt As System.Windows.Forms.Panel
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents MatId As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MaterialName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Qty As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Rate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GST As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GSTAmt As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Amount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TotalAmt As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
