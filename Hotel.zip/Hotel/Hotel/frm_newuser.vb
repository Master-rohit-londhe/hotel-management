﻿Imports System.Data.OleDb

Public Class frm_newuser

    Private Sub frm_newuser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        clear()
        generateID()
    End Sub
    Sub clear()
        cmbdesignation.Text = ""
        txtusername.Text = ""
        txtnewpassword.Text = ""
        txtconfirmpassword.Text = ""
    End Sub
    Sub generateID()
        On Error Resume Next
        cmbdesignation.Focus()
        cn.Open()
        cmd = New OleDb.OleDbCommand("select * from tb_login", cn)
        Dim reader As OleDbDataReader = cmd.ExecuteReader
        If (reader.Read = True) Then
            strsql = "select max(ID)from tb_login"
            cmd = New OleDb.OleDbCommand(strsql, cn)
            oadp = New OleDb.OleDbDataAdapter(cmd)
            otable = New DataTable("tb_login")
            oadp.Fill(otable)
            row = otable.Rows(0)
            txtno.Text = row.Item(0) + 1
        ElseIf (reader.Read = False) Then
            txtno.Text = "1"
        End If
        cn.Close()
    End Sub

    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        On Error Resume Next
        cn.Open()
        If cmbdesignation.Text = "" Then
            MsgBox("Please enter designation", MsgBoxStyle.OkOnly, "Error")
            cmbdesignation.Focus()
        ElseIf txtusername.Text = "" Then
            MsgBox("Please enter username", MsgBoxStyle.OkOnly, "Error")
            txtusername.Focus()
        ElseIf (Me.txtnewpassword.Text <> Me.txtconfirmpassword.Text) Then
            MsgBox("New Password and Confirn Password are not same", MsgBoxStyle.OkOnly, "Error")
            txtconfirmpassword.Focus()
        Else
            strsql = "SELECT * FROM tb_login WHERE username ='" & txtusername.Text & "'"
            cmd = New OleDbCommand(strsql, cn)
            Dim dr As OleDbDataReader
            dr = cmd.ExecuteReader()
            If Not dr.HasRows Then

                strsql = "insert into tb_login values(" & Val(txtno.Text) & ",'" & cmbdesignation.Text & "','" & txtusername.Text & "','" & txtnewpassword.Text & "')"
                cmd = New OleDb.OleDbCommand(strsql, cn)
                cmd.ExecuteNonQuery()
                MsgBox("New User Added Successfully", MsgBoxStyle.DefaultButton1, "Hotel")
                clear()
            Else
                MsgBox("Username already exist..")
                txtusername.Focus()
            End If
        End If
        cn.Close()
        generateID()
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        clear()
        generateID()
    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
    End Sub
End Class